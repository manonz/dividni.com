﻿using System;

namespace Utilities.Courses
{
   class Program
   {
      static void Main(string[] args)
      {
         Random random = new Random(37);                 
      }
   }
}
