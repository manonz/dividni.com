The basic principle is to leave the randomizer intact so that we don't change any of the original questions or answers.

Post exam corrections are therefore done in C# files and print out on a side-channel (typically standard output) the question number, the new expected answer code, and the marks for the question.

We then take the corrections and patch up the original answer files.

Here we have some examples of how this might be done in a number of scenarios. The examples can be adapted to handle specific cases.

We will look at both Truth as well as Xyz questions, but given that the corrections are specified in C# files, the techniques used therein are equally applicable to native C# questions.

Please note that it is best to avoid having errors in the exams. Before the exams go to print:
1) Triple-check all questions and answers. 
2) Get the exam sources as well as some complete instances reviewed by a colleague. 
3) Get some tutors/TAs to work through all questions in (different) exam instances. 

**Note**
When running TestGen to generate corrections, do not use the -proof option. This is because the -proof option internally prefixes the correct answer(s) with prefixes and therefore you would have to manually take the prefix into account.

Dividni comes with a tool McqPatch that will patch your answer files from the console log printed out by TestGen. To use this, you need to follow the output format (question_id<tab>answer_code<tab>mark) as shown in the provided examples.