using System;

namespace Utilities.Courses
{
   public partial class QHelper : IQHelper
   {
      // Please provide a meaningful name to this method. This is the name you'd use in the HTML
      // template to refer to this (method representing the) question.
      public static string QId01(Random random, Action<string, ushort> registerAnswer, bool isProof)
      {
         var q = Quest(random, isProof);
         string rval = q.GetQuestion(registerAnswer);
         return rval;
      } // QId01

      // Forming the question in a separate method allows us to generate an HTML
      // preview of the question. The preview is helpful to review the question.
      public static QuestionBase Quest(Random random, bool isProof)
      {
         var q = new XyzQuestion(random, isProof);
         q.Id = "QId01"; // The Id is used in error-reporting. Please let it be meaningful and unique.
         q.Marks = 2;
         q.Stem = @"What is our question?";
         q.AddCorrects(
            @"correct 1",
            @"correct 2",
            @"correct 3",
            @"correct 4",
            @"correct 5"
         );
         q.AddIncorrects(
            @"incorrect 1",
            @"incorrect 2",
            @"incorrect 3",
            @"incorrect 4",
            @"incorrect 5",
            @"incorrect 6"
         );
         return q;
      } // Quest
   } // class
} // namespace
