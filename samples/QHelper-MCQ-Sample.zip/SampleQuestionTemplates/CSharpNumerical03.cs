using System;
using System.Text;

namespace Utilities.Courses
{
   public partial class QHelper : IQHelper
   {
      public static QuestionBase QuadraticAnswerQ(Random random, bool isProof)
      {
         var q = new NumericalQuestion(random, isProof);
         q.Id = "Quadratic"; // The Id is used in error-reporting. Please let it be meaningful and unique.
         q.Marks = 2;
         int a = random.Next(2, 10);
         int b = random.Next(11, 20);
         int x = random.Next(11, 100);
         int c = a*x*x + b*x;
         StringBuilder sb = new StringBuilder();
         sb.AppendLine("What is the positive x value that satisfies the equation ");
         sb.AppendFormat("{0}x<sup>2</sup> + {1}x - {2}?", a, b, c);
         q.Stem = sb.ToString();
         q.AnsGTE = q.AnsLTE = x.ToString();
         return q;
      } // QuadraticAnswerQ
   } // class
} // namespace
