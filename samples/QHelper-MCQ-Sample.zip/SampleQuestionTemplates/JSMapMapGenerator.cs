﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Utilities.Courses
{
   public class JSMapMapGenerator
   {
      public JSMapMapGenerator(Random random)
      {
         frstMod = random.Next(2, 4);
         scndMod = random.Next(2, 4);
         kValue = random.Next(8, 11);
         kPlusConst = random.Next(9, 12);
         int n = random.Next(4, 6);
         int cnt = 0;
         var vals = new HashSet<int>();
         while (cnt < 2 * n)
         {
            int val = random.Next(2, 10);
            vals.Add(val);
            vals.Add(2 * val);
            vals.Add(3 * val);
            ++cnt;
         }
         intList = vals.OrderBy(x => x);
      } // JSMapMapGenerator

      public string FirstModCode()
      {
         string rval = string.Format("(x % {0} !== 0)", frstMod);
         return rval;
      } // FirstModCode

      public string SecondModCode()
      {
         string rval = string.Format("(k+{0}) % {1}", kPlusConst, scndMod);
         return rval;
      } // SecondModCode

      public string ListToUse() => ListGenJS.GetStringList(intList);

      public string KValue() => kValue.ToString();

      public List<string> Answers()
      {
         var rval = new List<string>();
         int k;
         string listAsString;
         IEnumerable<int> nList;

         k = kValue; // reset
         nList = intList.Select((e) => (e % frstMod != 0) ? ((k + kPlusConst) % scndMod) : ++k);
         listAsString = ListGenJS.GetStringList(nList);
         if (!rval.Contains(listAsString)) rval.Add(listAsString);

         k = kValue; // reset
         nList = intList.Select((e) => ((e + kPlusConst) % scndMod));
         listAsString = ListGenJS.GetStringList(nList);
         if (!rval.Contains(listAsString)) rval.Add(listAsString);

         k = kValue; // reset
         nList = intList.Select((e) => ++k);
         listAsString = ListGenJS.GetStringList(nList);
         if (!rval.Contains(listAsString)) rval.Add(listAsString);

         k = kValue; // reset
         nList = intList.Select((e) => (e % frstMod == 0) ? ((k + kPlusConst) % scndMod) : ++k);
         listAsString = ListGenJS.GetStringList(nList);
         if (!rval.Contains(listAsString)) rval.Add(listAsString);

         k = kValue; // reset
         nList = intList.Select((e) => (e % scndMod != 0) ? ((k + kPlusConst) % frstMod) : ++k);
         listAsString = ListGenJS.GetStringList(nList);
         if (!rval.Contains(listAsString)) rval.Add(listAsString);

         k = kValue; // reset
         nList = intList.Select((e) => (e % scndMod == 0) ? ((k + kPlusConst) % frstMod) : ++k);
         listAsString = ListGenJS.GetStringList(nList);
         if (!rval.Contains(listAsString)) rval.Add(listAsString);

         k = kValue; // reset
         nList = intList.Select((e) => (e  + kPlusConst));
         listAsString = ListGenJS.GetStringList(nList);
         if (!rval.Contains(listAsString)) rval.Add(listAsString);

         k = kValue; // reset
         nList = intList.Select((e) => e);
         listAsString = ListGenJS.GetStringList(nList);
         if (!rval.Contains(listAsString)) rval.Add(listAsString);

         //k = kValue; // reset
         //nList = intList.Select((e) => (e % frstMod != 0) ? ((k + kPlusConst) % scndMod) : ++k);
         //listAsString = GetStringList(nList);
         //if (!rval.Contains(listAsString)) rval.Add(listAsString);

         return rval;
      } // Answers

      private string Answer(Func<int, bool> predicate)
         => ListGenJS.GetStringList(intList.Where(predicate));

      private readonly int frstMod;
      private readonly int kPlusConst;
      private readonly int scndMod;
      private int kValue;
      private IEnumerable<int> intList = null;
   } // class
} // namespace
