using System;

namespace Utilities.Courses
{
   public partial class QHelper : IQHelper
   {
      // Please provide a meaningful name to this method. This is the name you'd use in the HTML
      // template to refer to this (method representing the) question.
      public static string Addition(Random random, Action<string, ushort> registerAnswer, bool isProof)
      {
         var q = AdditionQ(random, isProof);
         string rval = q.GetQuestion(registerAnswer);
         return rval;
      } // Addition

      // Forming the question in a separate method allows us to generate an HTML
      // preview of the question. The preview is helpful to review the question.
      public static QuestionBase AdditionQ(Random random, bool isProof)
      {
         var q = new TruthQuestion(random, isProof);
         q.Id = "Addition"; // The Id is used in error-reporting. Please let it be meaningful and unique.
         q.Marks = 2;
         int a = random.Next(2, 10);
         int b = random.Next(11, 20);
         q.Stem = string.Format("What is the sum of {0} and {1}?", a, b);
         q.AddCorrects(
            (a + b).ToString()
         );
         q.AddIncorrects(
            (a + b - 1).ToString(),
            (a + b + 1).ToString(),
            (a + b + 2).ToString(),
            (a + b + 3).ToString(),
            (b - a).ToString(), // Is this a good distractor?
            (a * b).ToString() // Is this a good distractor?
         );
         return q;
      } // AdditionQ
   } // class
} // namespace
