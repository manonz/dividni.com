using System;

namespace Utilities.Courses
{
   public partial class QHelper : IQHelper
   {
      public static QuestionBase SumShortAnswerQ(Random random, bool isProof)
      {
         var q = new NumericalQuestion(random, isProof);
         q.Id = "SumShortAns"; // The Id is used in error-reporting. Please let it be meaningful and unique.
         q.Marks = 2;
         int a = random.Next(2, 10);
         int b = random.Next(11, 20);
         q.Stem = string.Format("What is the sum of {0} and {1}?", a, b);
         q.AnsGTE = q.AnsLTE = (a + b).ToString();
         return q;
      } // SumShortAnswerQ
   } // class
} // namespace
