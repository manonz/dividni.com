using System;
using System.Text;

namespace Utilities.Courses
{
   public partial class QHelper : IQHelper
   {
      // Please provide a meaningful name to this method. This is the name you'd use in the HTML
      // template to refer to this (method representing the) question.
      public static string ApplesAndOranges(Random random, Action<string, ushort> registerAnswer, bool isProof)
      {
         var q = ApplesAndOrangesQ(random, isProof);
         string rval = q.GetQuestion(registerAnswer);
         return rval;
      } // ApplesAndOranges

      // Forming the question in a separate method allows us to generate an HTML
      // preview of the question. The preview is helpful to review the question.
      public static QuestionBase ApplesAndOrangesQ(Random random, bool isProof)
      {
         var q = new TruthQuestion(random, isProof);
         q.Id = "ApplesAndOranges"; // The Id is used in error-reporting. Please let it be meaningful and unique.
         q.Marks = 2;
         int appleCnt1 = 1, orangeCnt1 = 1,  appleCnt2 = 1, orangeCnt2 = 1;
         while (appleCnt1*orangeCnt2 == appleCnt2*orangeCnt1)
         {
            appleCnt1 = random.Next(2, 6);
            orangeCnt1 = random.Next(6, 10);
            appleCnt2 = random.Next(10, 15);
            orangeCnt2 = random.Next(15, 20);
         }
         int applePrice = 2 * random.Next(4, 9);
         int orangePrice = 2 * random.Next(11, 19);
         int totalPrice1 = appleCnt1 * applePrice + orangeCnt1 * orangePrice;
         int totalPrice2 = appleCnt2 * applePrice + orangeCnt2 * orangePrice;
         StringBuilder sb = new StringBuilder();
         sb.AppendFormat("At Prancing Pony, you can buy {0} apples and {1} oranges for {2} Castars; ",
             appleCnt1, orangeCnt1, totalPrice1);
         sb.AppendFormat("you can also buy {0} apples and {1} oranges for {2} Castars. ",
             appleCnt2, orangeCnt2, totalPrice2);
         sb.AppendLine("What is the price of a single apple, expressed in Castars?");

         q.Stem = sb.ToString();
         q.AddCorrects(
            applePrice.ToString()
         );
         q.AddIncorrects(
            orangePrice.ToString(),
            (orangePrice + 1).ToString(),
            (orangePrice - 1).ToString(),
            (orangePrice + 2).ToString(),
            (orangePrice - 2).ToString(),
            (applePrice + 1).ToString(),
            (applePrice - 1).ToString(),
            (applePrice + 2).ToString(),
            (applePrice - 2).ToString()
         );
         return q;
      } // ApplesAndOrangesQ
   } // class
} // namespace
