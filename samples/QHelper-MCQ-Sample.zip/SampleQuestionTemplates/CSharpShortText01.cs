using System;

namespace Utilities.Courses
{
   public partial class QHelper : IQHelper
   {
      public static QuestionBase BondsFirstName(Random random, bool isProof)
      {
         var q = new ShortTextQuestion(random, isProof);
         q.Id = "SampleTextQ"; // The Id is used in error-reporting. Please let it be meaningful and unique.
         q.Marks = 2;
         // Do make use of "random" to create variations.
         q.Stem = string.Format("What is Bond's first name?");
         q.Answers.Add("James");
         q.Answers.Add("Jim");
         q.Answers.Add("Jimmie");
         q.Answers.Add("Jimmy");
         return q;
      } // BondsFirstName
   } // class
} // namespace
