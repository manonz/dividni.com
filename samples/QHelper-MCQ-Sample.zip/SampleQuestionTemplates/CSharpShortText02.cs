using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace Utilities.Courses
{
   public class ShortTextQuestionEx : ShortTextQuestion
   {
      public ShortTextQuestionEx(Random random, bool isProof)
         : base(random, isProof)
      {
      }

      public override bool IsCorrectAnswer(string submittedAns)
      {
         submittedAns = Regex.Replace(submittedAns, @"\s+", "");
         return base.IsCorrectAnswer(submittedAns);
      } // IsCorrectAnswer
   }

   public partial class QHelper : IQHelper
   {
      public static QuestionBase JSMapMapQ(Random random, bool isProof)
      {
         var q = new ShortTextQuestionEx(random, isProof);
         q.Id = "JSMapMapQ"; // The Id is used in error-reporting. Please let it be meaningful and unique.
         q.Marks = 2;
         // Do make use of "random" to create variations.
         JSMapMapGenerator mmg = new JSMapMapGenerator(random);
         StringBuilder sb = new StringBuilder();

         sb.AppendLine("Consider the following JavaScript code block.");
         sb.AppendLine("<br />");
         sb.AppendLine("<br />");
         sb.AppendLine("<div style='border: 1px solid black; border-radius: 5px; padding: 10px;'>");
         sb.AppendLine("   <code>const list = " + mmg.ListToUse() + ";</code><br />");
         sb.AppendLine("   <code>let k = " + mmg.KValue() + ";</code><br />");
         sb.Append("   <code>const p = list.map((x) => " + mmg.FirstModCode() + ")");
         sb.AppendLine(".map((x) => x ? </code>");
         sb.AppendLine("   <code>" + mmg.SecondModCode() + "</code>");
         sb.AppendLine("   <code> : ++k);</code><br />");
         sb.AppendLine("</div>");
         sb.AppendLine("<br />");
         sb.AppendLine("What is the value of <code>p</code>?<br/>");
         sb.AppendLine(string.Format("Your answer should be of the form <code>{0}</code>",
            "[3, 4, 5]"));

         q.Stem = sb.ToString();
         string ans = mmg.Answer();
         q.Answers.Add(Regex.Replace(ans, @"\s+", ""));
         return q;
      } // JSMapMapQ
   } // class

   public class JSMapMapGenerator
   {
      public JSMapMapGenerator(Random random)
      {
         frstMod = random.Next(2, 4);
         scndMod = random.Next(2, 4);
         kValue = random.Next(8, 11);
         kPlusConst = random.Next(9, 12);
         int n = random.Next(1, 1);
         int cnt = 0;
         var vals = new HashSet<int>();
         while (cnt < 2 * n)
         {
            int val = random.Next(2, 10);
            vals.Add(val);
            vals.Add(2 * val);
            vals.Add(3 * val);
            ++cnt;
         }
         intList = vals.OrderBy(x => x);
      } // JSMapMapGenerator

      public string FirstModCode()
      {
         string rval = string.Format("(x % {0} !== 0)", frstMod);
         return rval;
      } // FirstModCode

      public string SecondModCode()
      {
         string rval = string.Format("(k+{0}) % {1}", kPlusConst, scndMod);
         return rval;
      } // SecondModCode

      public string ListToUse() { return GetStringList(intList); }

      public string KValue() { return kValue.ToString(); }

      public string Answer()
      {
         int k = kValue;
         var nList = intList.Select((e) => (e % frstMod != 0) ? ((k + kPlusConst) % scndMod) : ++k).ToList();
         string listAsString = GetStringList(nList);

         return listAsString;
      } // Answer

      public static string GetStringList<T>(IEnumerable<T> lst)
      {
         var sb = new StringBuilder();
         sb.Append("[ ");
         int elemCount = lst.Count();
         for (int i = 0; i < elemCount; ++i)
         {
            sb.AppendFormat((i < elemCount - 1) ? "{0}, " : "{0}", lst.ElementAt(i).ToString());
         }
         sb.Append(" ]");
         return sb.ToString();
      } // GetStringList

      private readonly int frstMod;
      private readonly int kPlusConst;
      private readonly int scndMod;
      private int kValue;
      private IEnumerable<int> intList = null;
   } // class
} // namespace
