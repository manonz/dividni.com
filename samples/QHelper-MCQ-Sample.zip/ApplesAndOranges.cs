using System;
using System.Text;

namespace Utilities.Courses
{
   public partial class QHelper : IQHelper
   {
      public static string ApplesAndOranges(Random random, Action<string, ushort> registerAnswer, bool isProof)
      {
         var q = new TruthQuestion(random, isProof);
         q.Id = "ApplesAndOranges";
         q.Marks = 2;
         int appleCnt1 = 1, orangeCnt1 = 1,  appleCnt2 = 1, orangeCnt2 = 1;
         while (appleCnt1*orangeCnt2 == appleCnt2*orangeCnt1)
         {
            appleCnt1 = random.Next(2, 6);
            orangeCnt1 = random.Next(6, 10);
            appleCnt2 = random.Next(10, 15);
            orangeCnt2 = random.Next(15, 20);
         }
         int applePrice = 2 * random.Next(4, 9);
         int orangePrice = 2 * random.Next(11, 19);
         int totalPrice1 = appleCnt1 * applePrice + orangeCnt1 * orangePrice;
         int totalPrice2 = appleCnt2 * applePrice + orangeCnt2 * orangePrice;
         StringBuilder sb = new StringBuilder();
         sb.Append($"At Prancing Pony, you can buy {appleCnt1} apples and {orangeCnt1} oranges for {totalPrice1} Castars; ");
         sb.Append($"you can also buy {appleCnt2} apples and {orangeCnt2} oranges for {totalPrice2} Castars. ");
         sb.AppendLine("What is the price of a single apple, expressed in Castars?");

         q.Stem = sb.ToString();
         q.AddCorrects(
            applePrice.ToString()
         );
         q.AddIncorrects(
            orangePrice.ToString(),
            (orangePrice + 1).ToString(),
            (orangePrice - 1).ToString(),
            (orangePrice + 2).ToString(),
            (orangePrice - 2).ToString(),
            (applePrice + 1).ToString(),
            (applePrice - 1).ToString(),
            (applePrice + 2).ToString(),
            (applePrice - 2).ToString()
         );

         string rval = q.GetQuestion(registerAnswer);
         return rval;
      } // ApplesAndOranges
   } // class
} // namespace
