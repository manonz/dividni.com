using System;
using System.Diagnostics;

namespace Utilities.Courses
{
   public partial class QHelper : IQHelper
   {
      public static string InitAppleOrangeBasket(Random random, Action<string, ushort> registerAnswer, bool isProof)
      {
         appleOrangeBasket = new AppleOrangeBasket(random);
         return "";
      }
      public static string AppleCount1(Random random, Action<string, ushort> registerAnswer, bool isProof)
      {
         Debug.Assert(appleOrangeBasket != null);
         return appleOrangeBasket.appleCnt1.ToString();
      }
      public static string AppleCount2(Random random, Action<string, ushort> registerAnswer, bool isProof)
      {
         Debug.Assert(appleOrangeBasket != null);
         return appleOrangeBasket.appleCnt2.ToString();
      }
      public static string OrangeCount1(Random random, Action<string, ushort> registerAnswer, bool isProof)
      {
         Debug.Assert(appleOrangeBasket != null);
         return appleOrangeBasket.orangeCnt1.ToString();
      }
      public static string OrangeCount2(Random random, Action<string, ushort> registerAnswer, bool isProof)
      {
         Debug.Assert(appleOrangeBasket != null);
         return appleOrangeBasket.orangeCnt2.ToString();
      }
      public static string TotalPrice1(Random random, Action<string, ushort> registerAnswer, bool isProof)
      {
         Debug.Assert(appleOrangeBasket != null);
         return appleOrangeBasket.totalPrice1.ToString();
      }
      public static string TotalPrice2(Random random, Action<string, ushort> registerAnswer, bool isProof)
      {
         Debug.Assert(appleOrangeBasket != null);
         return appleOrangeBasket.totalPrice2.ToString();
      }
      public static string ApplePriceAndDistractors(Random random, Action<string, ushort> registerAnswer, bool isProof)
      {
         Debug.Assert(appleOrangeBasket != null);
         var q = new TruthQuestion(random, isProof);
         q.AddCorrects(
            appleOrangeBasket.applePrice.ToString()
         );
         q.AddIncorrects(
             appleOrangeBasket.orangePrice.ToString(),
            (appleOrangeBasket.orangePrice + 1).ToString(),
            (appleOrangeBasket.orangePrice - 1).ToString(),
            (appleOrangeBasket.orangePrice + 2).ToString(),
            (appleOrangeBasket.orangePrice - 2).ToString(),
            (appleOrangeBasket.applePrice + 1).ToString(),
            (appleOrangeBasket.applePrice - 1).ToString(),
            (appleOrangeBasket.applePrice + 2).ToString(),
            (appleOrangeBasket.applePrice - 2).ToString()
         );
         q.Id = "ApplesAndOranges2";
         q.Marks = 2;

         string rval = q.GetQuestion(registerAnswer);
         return rval;
      }

      private static AppleOrangeBasket appleOrangeBasket = null!;
   } // class

   class AppleOrangeBasket
   {
      internal AppleOrangeBasket(Random random)
      {
         while (appleCnt1 * orangeCnt2 == appleCnt2 * orangeCnt1)
         {
            appleCnt1 = random.Next(2, 6);
            orangeCnt1 = random.Next(6, 10);
            appleCnt2 = random.Next(10, 15);
            orangeCnt2 = random.Next(15, 20);
         }
         applePrice = 2 * random.Next(4, 9);
         orangePrice = 2 * random.Next(11, 19);
         totalPrice1 = appleCnt1 * applePrice + orangeCnt1 * orangePrice;
         totalPrice2 = appleCnt2 * applePrice + orangeCnt2 * orangePrice;
      } // AppleOrangeBasket

      internal int appleCnt1 = 1, orangeCnt1 = 1, appleCnt2 = 1, orangeCnt2 = 1;
      internal int applePrice, orangePrice;
      internal int totalPrice1, totalPrice2;
   } // class
} // namespace
