﻿// Assignment Arithmetic Template. S Manoharan.

using System;
using System.Collections.Generic;
using System.Text;

namespace Utilities.Courses
{
   public class Arithmetic
   {
      public Arithmetic(Random random)
      {
         int maxNums = random.Next(5, 9);
         numbers.Clear();
         for (int i = 0; i < maxNums; ++i)
         {
            numbers.Add(random.Next(1, 9));
         }
      } // Arithmetic

      public string GetNumbers()
      {
         StringBuilder sb = new StringBuilder();
         sb.AppendFormat("{0}", numbers[0]);
         for (int i = 1; i < numbers.Count; ++i)
         {
            sb.AppendFormat(", {0}", numbers[i]);
         }
         return sb.ToString();
      } // GetNumbers

      public string GetSum()
      {
         int sum = 0;
         for (int i = 0; i < numbers.Count; ++i)
         {
            sum += numbers[i];
         }
         return sum.ToString();
      } // GetSum

      public string GetProduct()
      {
         int prod = 1;
         for (int i = 0; i < numbers.Count; ++i)
         {
            prod *= numbers[i];
         }
         return prod.ToString();
      } // GetProduct

      private readonly List<int> numbers = new List<int>();
   } // class
} // namespace
