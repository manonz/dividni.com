Compile the solution.
Issue the following commands in your command shell:

cd bin/Debug (or bin/Release, if appropriate).
TestGen -paperCount 20 -library QHelperArithmeticTask.dll Arithmetic.Task.html

To generate the sheets with answers, use the -proof option with TestGen. This enables the code within class cws_code_a to be visible.
TestGen -paperCount 20 -library QHelperArithmeticTask.dll -proof Arithmetic.Task.html

You can use wkhtmltopdf to convert the html tasksheets to pdf, if required.