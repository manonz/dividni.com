﻿using System;
using System.Diagnostics;

namespace Utilities.Courses
{
   public partial class QHelper : IQHelper
   {
      public static string InitNumbers(Random random, Action<string, ushort> registerAnswer,
         bool isProof)
      {
         arith = new Arithmetic(random);
         return string.Empty;
      } // InitNumbers

      public static string GetNumbers(Random random, Action<string, ushort> registerAnswer,
         bool isProof)
      {
         Debug.Assert(arith != null);
         return arith.GetNumbers();
      } // GetNumbers

      public static string GetSum(Random random, Action<string, ushort> registerAnswer,
         bool isProof)
      {
         Debug.Assert(arith != null);
         return arith.GetSum();
      } // GetSum

      public static string GetProduct(Random random, Action<string, ushort> registerAnswer,
         bool isProof)
      {
         Debug.Assert(arith != null);
         return arith.GetProduct();
      } // GetProduct

      public static Arithmetic arith = null;
   } // class
} // namespace
