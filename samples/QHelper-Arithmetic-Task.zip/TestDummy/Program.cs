﻿using System;

namespace Utilities.Courses
{
   class Program
   {
      static void Main(string[] args)
      {
         Random random = new Random(42);
         //var task = new Arithmetic(random);
         //var p = task.GetNumbers();
      }
   }
}
