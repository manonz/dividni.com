﻿// Sample Assignment Template - Arithmetic Operations. S Manoharan.
//
// There are three parts to an assignment: 
//    (1) assignment specification in HTML
//    (2) answer sheet in plaintext 
//    (3) marking result in plaintext
// These parts are served as separate endpoints, and they are 
// independent of each other in the HTTP sense - they are stateless
// or often called RESTful. Any initialization using student ID
// must be done for each of the three endpoints. Initialization
// in the case of this example is done via the method InitInputs
// and this method must therefore be called in all three of the
// endpoint contexts. Thus, at the beginning of the HTML template 
// you see this call: <p class="cws_code_q">InitInputs</p>
// Similary, both of the Answers() and MarkingResult()
// call InitInputs() before they do anything else.

using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;

namespace Utilities.Courses
{
   public class Arithmetic : TemplatedCoursework
   {
      public override void Initialize()
      {
         base.Initialize();
      } // Initialize

      public string InitInputs(uint uid)
      {
         Random random = GetRandom(uid);
         int maxNums = random.Next(5, 9);
         numbers.Clear();
         for (int i = 0; i < maxNums; ++i)
         {
            numbers.Add(random.Next(1, 9));
         }
         return "";
      } // InitInputs

      public override string Answers(bool withAnswers, uint uid)
      {
         InitInputs(uid);
         var sb = new StringBuilder();
         sb.AppendFormat($"AUID: {uid}");
         sb.AppendLine();
         WriteAnswers(sb, GetSum(uid), "1", withAnswers);
         WriteAnswers(sb, GetProduct(uid), "2", withAnswers);

         return sb.ToString();
      } // Answers

      private void WriteAnswers(StringBuilder sb, string answer, string partId, bool withAnswers)
      {
         sb.AppendFormat($"{partId}: {(withAnswers ? answer : string.Empty)}");
         sb.AppendLine();
      } // WriteAnswers

      public override string MarkingResult(bool withAnswers, uint uid, string submission, out double mark)
      {
         InitInputs(uid);
         mark = 0.0;
         var sb = new StringBuilder();

         Dictionary<string, string> kvp = ProcessAnswerFile(submission);
         string a1_aS = SubmittedAnswer(kvp, "1");
         string a2_aS = SubmittedAnswer(kvp, "2");

         if (withAnswers)
         {
            sb.AppendLine($"1: correct answer: [{GetSum(uid)}]; your answer: [{a1_aS}]");
            sb.AppendLine($"2: correct answer: [{GetProduct(uid)}]; your answer: [{a2_aS}]");
         }

         if (a1_aS == GetSum(uid)) mark += 1; else { sb.AppendLine("1: INCORRECT ANSWER"); }
         if (a2_aS == GetProduct(uid)) mark += 1; else { sb.AppendLine("2: INCORRECT ANSWER"); }

         sb.AppendLine();
         sb.AppendLine($"Your total marks: {mark}/2");
         return sb.ToString();
      } // MarkingResult

      private static string SubmittedAnswer(Dictionary<string, string> kvp, string qId)
      {
         string a = kvp.ContainsKey(qId) ? Regex.Replace(kvp[qId], @"\s+", "") : "";
         return a;
      } // SubmittedAnswer

      public string GetNumbers(uint _)
      {
         var sb = new StringBuilder();
         sb.Append($"{numbers[0]}");
         for (int i = 1; i < numbers.Count; ++i)
         {
            sb.Append($", {numbers[i]}");
         }
         return sb.ToString();
      } // GetNumbers

      public string GetSum(uint _)
      {
         int sum = 0;
         for (int i = 0; i < numbers.Count; ++i)
         {
            sum += numbers[i];
         }
         return sum.ToString();
      } // GetSum

      public string GetProduct(uint _)
      {
         int prod = 1;
         for (int i = 0; i < numbers.Count; ++i)
         {
            prod *= numbers[i];
         }
         return prod.ToString();
      } // GetProduct

      private readonly List<int> numbers = new();
   } // class
} // namespace
