The project file supplied here assumes that Dividni is installed in the folder "C:\Program Files\Dividni". If you have it installed somewhere else, please update this to the location when you have the installation. 

Issue "dotnet build" in this folder (where you have this assignment template) to build the assignment.