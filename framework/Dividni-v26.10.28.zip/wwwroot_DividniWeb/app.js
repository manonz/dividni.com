"use strict";

import {
   renderExams,
   renderExam,
   renderError
} from "./rendering.js";

import { state } from "./state.js";

import {
   loadConfig,
   loadVersion,
   loadExams,
   openExam,
   changeSection,
   closeExam,
   showNewExamDialog,
   createExam,
   saveManifest,
   runProof,
   runProofPdf,
   runProduction,
   runProductionPdf,
   runProductionPackage,
   runGrading,
   runMail
} from "./workflow.js";

import {
   addComposition,
   moveComposition,
   removeComposition,
   markDirty,
   addMissingGenerators,
   openAssetPicker,
   selectAsset,
   closeAssetPicker
} from "./preparation.js";


const footerVersion =
   document.querySelector("#version");

const backButton =
   document.querySelector("#backButton");

const brandButton =
   document.querySelector("#brandButton");

const cancelDialog =
   document.querySelector("#cancelDialog");

const closeDialog =
   document.querySelector("#closeDialog");

const newExamForm =
   document.querySelector("#newExamForm");


// ------------------------------------------------------------
// Initialisation
// ------------------------------------------------------------

async function initialise() {
   try {

      // Read configuration before attempting to list exams.
      await loadConfig();

      const version =
         await loadVersion();

      footerVersion.textContent =
         version?.version
            ? `McqTestGen ${version.version}`
            : "McqTestGen unavailable";

      if (state.config.settingsFileExists) {
         await loadExams();
      } else {
         // First-time setup: do not request /api/exams yet.
         state.exams = [];
      }

      renderExams();

   } catch (error) {
      renderError(error);
   }
}

// ------------------------------------------------------------
// Long-running operations
// ------------------------------------------------------------

async function runLongOperation(
   name,
   operation) {

   if (state.busyOperation) {
      return;
   }

   state.busyOperation = name;

   try {

      await operation();

   } finally {

      state.busyOperation = null;

      if (state.exam) {
         renderExam();
      }
   }
}


// ------------------------------------------------------------
// Manifest and post-exam input editing
// ------------------------------------------------------------

document.addEventListener(
   "input",
   event => {

      if (event.target.id === "responsesFile") {
         state.responsesFile =
            event.target.value;
      }

      if (event.target.id === "idMapFile") {
         state.idMapFile =
            event.target.value;
      }

      if (
         event.target.closest(
            "#manifestForm"
         )
      ) {
         markDirty();
      }
   }
);


// ------------------------------------------------------------
// Application actions
// ------------------------------------------------------------

document.addEventListener(
   "click",
   async event => {

      const button =
         event.target.closest(
            "[data-action]"
         );

      if (!button) {
         return;
      }

      // Ignore all delegated actions while a
      // long-running operation is in progress.
      if (state.busyOperation) {
         return;
      }

      switch (button.dataset.action) {

         case "new-exam":
            showNewExamDialog();
            break;

         case "open-exam":
            await openExam(
               button.dataset.id
            );
            break;

         case "section":
            await changeSection(
               button.dataset.section
            );
            break;

         case "move":
            moveComposition(
               Number(
                  button.dataset.index
               ),
               Number(
                  button.dataset.delta
               ),
               renderExam
            );
            break;

         case "remove":
            removeComposition(
               Number(
                  button.dataset.index
               ),
               renderExam
            );
            break;

         case "add":
            addComposition(
               renderExam
            );
            break;

         case "save":
            await saveManifest();
            break;

         case "add-missing-generators":
            await addMissingGenerators(
               renderExam
            );
            break;

         case "browse-asset":
            await openAssetPicker(
               button.dataset.field,
               button.dataset.kind
            );
            break;

         case "select-asset":
            selectAsset(
               button.dataset.field,
               button.dataset.value,
               renderExam
            );
            break;

         case "proof":
            await runLongOperation(
               "proof",
               runProof
            );
            break;

         case "proof-pdf":
            await runLongOperation(
               "proof-pdf",
               runProofPdf
            );
            break;

         case "production": {
            if (
               state.productionAvailable &&
               !window.confirm(
                  `Production files for ${state.productionPaperCount} papers already exist. ` +
                  "Generating production will replace the existing production folder. Continue?"
               )
            ) {
               break;
            }

            const paperCount =
               document.querySelector(
                  "#paperCount"
               )?.value;

            await runLongOperation(
               "production",
               () => runProduction(paperCount)
            );

            break;
         }

         case "production-pdf":
            await runLongOperation(
               "production-pdf",
               runProductionPdf
            );
            break;

         case "production-package":
            await runLongOperation(
               "production-package",
               runProductionPackage
            );
            break;

         case "grade":
            await runGrading(
               document.querySelector(
                  "#responsesFile"
               )?.value
            );
            break;

         case "mail": {
            const idMapFile =
               document.querySelector(
                  "#idMapFile"
               )?.value;

            // TEST MODE: when MailmanService.cs is back in preview-only mode,
            // comment out the live confirmation/call below and uncomment:
            // await runMail(idMapFile);

            if (!window.confirm(
               "LIVE MAIL MODE: This will execute MailMan and may send real feedback emails to students. " +
               "Check the IdMap file and generated feedback before continuing. Continue?"
            )) {
               break;
            }

            await runMail(idMapFile);
            break;
         }

      }
   }
);


// ------------------------------------------------------------
// Navigation
// ------------------------------------------------------------

brandButton.addEventListener(
   "click",
   () => {
      if (!state.busyOperation) {
         closeExam();
      }
   }
);

backButton.addEventListener(
   "click",
   () => {
      if (!state.busyOperation) {
         closeExam();
      }
   }
);


// ------------------------------------------------------------
// New exam dialog
// ------------------------------------------------------------

cancelDialog.addEventListener(
   "click",
   () => {
      newExamForm
         .closest("dialog")
         .close();
   }
);

closeDialog.addEventListener(
   "click",
   () => {
      newExamForm
         .closest("dialog")
         .close();
   }
);

newExamForm.addEventListener(
   "submit",
   createExam
);


// ------------------------------------------------------------
// Asset dialog
// ------------------------------------------------------------

document
   .querySelector("#assetDialogCancel")
   .addEventListener(
      "click",
      closeAssetPicker
);

// ------------------------------------------------------------
// Service worker registration
// ------------------------------------------------------------

if ("serviceWorker" in navigator) {

   window.addEventListener("load", () => {

      navigator.serviceWorker
         .register("sw.js")
         .catch(error => {

            console.error(
               "Service worker registration failed:",
               error
            );

         });

   });

}
// ------------------------------------------------------------
// Start
// ------------------------------------------------------------

initialise();