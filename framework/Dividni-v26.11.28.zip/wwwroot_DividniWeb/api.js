"use strict";

const API_BASE = "/api";


async function getJson(path) {
   const response = await fetch(
      `${API_BASE}${path}`,
      {
         cache: "no-store",
         headers: {
            "Accept": "application/json"
         }
      }
   );

   if (!response.ok) {
      const body =
         await response.text();

      throw new Error(
         `GET ${path} failed: ` +
         `${response.status} ${response.statusText}\n` +
         body.substring(0, 200)
      );
   }

   const contentType =
      response.headers.get("content-type") || "";

   if (!contentType.includes("application/json")) {
      const body =
         await response.text();

      throw new Error(
         `GET ${path} returned ` +
         `${contentType || "unknown content type"} ` +
         `instead of JSON.\n` +
         body.substring(0, 200)
      );
   }

   return await response.json();
}


async function postJson(path, body) {
   const response = await fetch(
      `${API_BASE}${path}`,
      {
         method: "POST",
         headers: {
            "Accept": "application/json",
            "Content-Type": "application/json"
         },
         body: JSON.stringify(body)
      }
   );

   const contentType =
      response.headers.get("content-type") || "";

   const responseText =
      await response.text();

   if (!response.ok) {
      let message =
         responseText;

      try {
         const json =
            JSON.parse(responseText);

         message =
            json.error ||
            json.detail ||
            json.title ||
            responseText;

      } catch {
         // Keep plain response text.
      }

      throw new Error(
         message ||
         `${response.status} ${response.statusText}`
      );
   }

   if (!responseText) {
      return null;
   }

   return contentType.includes("application/json")
      ? JSON.parse(responseText)
      : null;
}


export async function getAssets(id) {
   return await getJson(
      `/exams/${encodeURIComponent(id)}/assets`
   );
}


export {
   getJson,
   postJson
};