"use strict";

import { state } from "./state.js";
import { escapeHtml } from "./utils.js";
import { preparationHtml } from "./preparation.js";


// ------------------------------------------------------------
// Long-running operation buttons
// ------------------------------------------------------------

const operationLabels = {
   proof: "Running proof…",
   "proof-pdf": "Generating PDF…",
   production: "Generating production…",
   "production-pdf": "Converting to PDF…",
   "production-package": "Creating printing files…",
   mail: "Running MailMan and sending feedback…"
};


function spinnerHtml() {
   return `
      <svg
          class="loading-spinner"
          viewBox="0 0 24 24"
          aria-hidden="true"
          focusable="false">
          <circle
              cx="12"
              cy="12"
              r="9">
          </circle>
          <path
              d="M12 3a9 9 0 0 1 9 9">
          </path>
      </svg>
   `;
}


function operationButton(
   action,
   label,
   style = "secondary",
   prerequisiteDisabled = false) {

   const active =
      state.busyOperation === action;

   const disabled =
      Boolean(state.busyOperation) || prerequisiteDisabled;

   const buttonLabel =
      active
         ? operationLabels[action]
         : label;

   return `
      <button
          class="${style}"
          type="button"
          data-action="${action}"
          ${disabled ? "disabled" : ""}
          aria-busy="${active}">
          ${active ? spinnerHtml() : ""}
          ${escapeHtml(buttonLabel)}
      </button>
   `;
}

function examPathFor(relativePath) {
   const root =
      String(state.examPath || "");

   const separator =
      root.includes("\\") ? "\\" : "/";

   const base =
      root.replace(/[\\/]+$/, "");

   const relative =
      relativePath
         .split(/[\\/]+/)
         .join(separator);

   return base
      ? `${base}${separator}${relative}`
      : relative;
}

// ------------------------------------------------------------
// Exam list
// ------------------------------------------------------------


export function renderExams() {
   const backButton =
      document.querySelector("#backButton");

   const brandButton =
      document.querySelector("#brandButton");

   backButton.hidden = true;

   backButton.disabled =
      Boolean(state.busyOperation);

   brandButton.disabled =
      Boolean(state.busyOperation);

   const app =
      document.querySelector("#app");

   // First-run setup is the only content shown
   // until the settings file exists.
   if (!state.config.settingsFileExists) {
      app.innerHTML = `
          <section class="page">
              ${setupHtml()}
          </section>
      `;
      return;
   }

   app.innerHTML = `
        <section class="page">
            <div class="page-heading">
                <div>
                    <p class="eyebrow">Examinations</p>
                    <h1>Exams</h1>
                </div>

                <button
                    class="primary"
                    type="button"
                    data-action="new-exam">
                    New exam
                </button>
            </div>

            <div class="exam-list">
                ${state.exams.length === 0
         ? `<div class="panel empty">No exams found.</div>`
         : state.exams.map(examCardHtml).join("")}
            </div>
        </section>
   `;
}


function setupHtml() {
   if (state.config.settingsFileExists) {
      return "";
   }

   return `
        <div class="panel">
            <div class="panel-heading">
                <h2>First-time setup</h2>
            </div>

            <p>
                DividniWeb needs a user settings file for
                machine-specific configuration such as the
                PDF converter and Mailman.
            </p>

            <p>
                Download the settings template, save it as
                <code>DividniWeb.settings.json</code> in your
                home folder, and edit the settings as required.
            </p>

            ${state.config.settingsFilePath
         ? `
                    <p>
                        <span class="muted">Required location:</span><br/><br/>
                        <code class="path-box">
                            ${escapeHtml(
            state.config.settingsFilePath)}
                        </code>
                    </p>
                 `
         : ""}

            <p class="muted">
                After creating the file, refresh this page.
            </p>

            <div class="actions">
                <a
                    class="secondary"
                    href="/DividniWeb.settings.example.json"
                    download="DividniWeb.settings.json">
                    Download settings template
                </a>
            </div>
        </div>
   `;
}


function examCardHtml(exam) {
   const status =
      exam.status || "";

   const statusClass =
      ["checkpointed", "production", "post-exam"].includes(status.toLowerCase())
         ? "success"
         : "";

   return `
        <button
            class="exam-card"
            type="button"
            data-action="open-exam"
            data-id="${escapeHtml(exam.id)}">

            <span>
                <span class="exam-title">
                    ${escapeHtml(exam.courseCode)}
                    —
                    ${escapeHtml(exam.date)}
                </span>

                <span class="exam-detail">
                    ${escapeHtml(exam.courseInfo)}
                </span>
            </span>

            <span class="badge ${statusClass}">
                ${escapeHtml(status)}
            </span>
        </button>
   `;
}


// ------------------------------------------------------------
// Exam page
// ------------------------------------------------------------

export function renderExam() {
   const backButton =
      document.querySelector("#backButton");

   const brandButton =
      document.querySelector("#brandButton");

   backButton.hidden = false;

   backButton.disabled =
      Boolean(state.busyOperation);

   brandButton.disabled =
      Boolean(state.busyOperation);

   const app =
      document.querySelector("#app");

   const tabs = [
      ["preparation", "Preparation"],
      ["proof", "Proof"],
      ["production", "Production"],
      ["post-exam", "Post-exam"]
   ];

   app.innerHTML = `
        <section class="page">
            <div class="page-heading">
                <div>
                    <p class="eyebrow">Exam</p>

                    <h1>
                        ${escapeHtml(state.exam.courseCode)}
                        —
                        ${escapeHtml(state.exam.date)}
                    </h1>

                    <p class="muted">
                        ${escapeHtml(state.exam.courseInfo)}
                    </p>
                </div>
            </div>

            <nav
                class="tabs"
                aria-label="Exam sections">

                ${tabs.map(
      ([id, label]) => `
                     <button
                         class="tab ${state.section === id
            ? "active"
            : ""
         }"
                         type="button"
                         data-action="section"
                         data-section="${id}"
                         ${state.busyOperation ? "disabled" : ""}>
                         ${label}
                     </button>
                   `
   ).join("")}
            </nav>

            ${state.status
         ? `
                 <div
                     class="status ${state.statusError
            ? "error"
            : "success"
         }"
                     role="status"
                     aria-live="polite">
                     ${escapeHtml(state.status)}
                 </div>
                 `
         : ""}

            ${state.section === "preparation" && state.postExamExists
         ? `
                <div class="status error" role="alert">
                    <strong>Manifest is read-only.</strong>
                    <p>
                        This exam has a post-exam directory, so its manifest cannot be changed.
                        If you really need to change the manifest, you must first delete the post-exam directory.
                        Back up any results you need, manually delete
                        <code>${escapeHtml(state.examPath)}/post-exam</code>, then switch sections
                        or reopen the exam to refresh its status.
                    </p>
                </div>
             `
         : ""}

            ${sectionHtml()}
        </section>
   `;

   // Enforce the lock in the UI. The backend independently enforces it too.
   if (state.postExamExists) {
      const manifestForm = app.querySelector("#manifestForm");
      if (manifestForm) {
         manifestForm.querySelectorAll("input, textarea, select, button")
            .forEach(control => { control.disabled = true; });
      }
   }
}


function sectionHtml() {
   switch (state.section) {
      case "proof":
         return proofHtml();

      case "production":
         return productionHtml();

      case "post-exam":
         return postExamHtml();

      case "preparation":
      default:
         return preparationHtml();
   }
}


// ------------------------------------------------------------
// Production
// ------------------------------------------------------------

function productionHtml() {
   const examId = encodeURIComponent(state.examId);
   const htmlCount = Number(state.productionPaperCount || 0);
   const pdfCount = Number(state.productionPdfCount || 0);
   const hasZip = state.productionZipAvailable === true;
   const hasCombined = state.productionCombinedPdfAvailable === true;
   const hasPackage = hasZip || hasCombined;

   return `
        <div class="panel">
            <div class="panel-heading">
                <h2>Production</h2>
            </div>

            <p class="muted">
                Generate the final exam papers and prepare files for printing.
                Output counts and download links reflect files currently present on disk.
            </p>

            <div class="field">
                <label class="field-label" for="paperCount">Number of papers</label>
                <input
                    id="paperCount"
                    type="number"
                    min="1"
                    step="1"
                    value="${htmlCount || ""}"
                    placeholder="Enter paper count">
            </div>

            <div class="actions">
                ${operationButton(
      "production",
      state.productionAvailable ? "Regenerate production" : "Generate production",
      "primary"
   )}
            </div>

            ${state.productionAvailable
         ? `
                <div class="panel">
                    <div class="panel-heading">
                        <h3>Production HTML</h3>
                    </div>
                    <p class="muted">
                        ${htmlCount} numbered HTML paper${htmlCount === 1 ? "" : "s"} exist.
                    </p>
                    <div class="actions">
                        ${operationButton("production-pdf", "Convert HTML to PDF")}
                    </div>
                </div>
             `
         : ""}

            ${state.productionPdfAvailable
         ? `
                <div class="panel">
                    <div class="panel-heading">
                        <h3>Production PDFs</h3>
                    </div>
                    <p class="muted">
                        ${pdfCount} numbered PDF${pdfCount === 1 ? "" : "s"} exist
                        for ${htmlCount} numbered HTML paper${htmlCount === 1 ? "" : "s"}.
                        ${state.productionPageCount > 0
            ? `The latest conversion reported ${state.productionPageCount} pages per paper.`
            : "Page count has not been rechecked during this session."}
                    </p>
                    ${pdfCount !== htmlCount
            ? `<p class="status error">The PDF count differs from the HTML paper count.</p>`
            : ""}
                    <div class="actions">
                        ${operationButton("production-package", "Create or recreate printing files")}
                    </div>
                </div>
             `
         : ""}

            ${hasPackage
         ? `
                <div class="panel">
                    <div class="panel-heading">
                        <h3>${hasZip && hasCombined
            ? "Printing files ready"
            : hasZip
               ? "Individual PDFs ZIP ready"
               : "Combined PDF ready"}
                        </h3>
                    </div>
                    <p class="muted">
                        ${hasZip && hasCombined
            ? "Both the individual PDF ZIP and combined PDF are present."
            : hasZip
               ? "The individual PDFs ZIP is present, but the combined PDF is missing."
               : "The combined PDF is present, but the individual PDFs ZIP is missing."}
                    </p>
                    ${hasZip && !hasCombined
            ? `
                        <div class="status error" role="alert">
                            <strong>Combined PDF not present.</strong>
                            <p>${escapeHtml(state.productionPackageError || "The previous merge may have failed. Recreate the printing files to try again.")}</p>
                        </div>
                     `
            : ""}
                    <div class="actions">
                        ${hasZip
            ? `<a class="secondary" href="/api/exams/${examId}/production/individual-pdfs.zip">Download individual PDFs ZIP</a>`
            : ""}
                        ${hasCombined
            ? `<a class="secondary" href="/api/exams/${examId}/production/all-papers.pdf" target="_blank" rel="noopener noreferrer">Download combined PDF ↗</a>`
            : ""}
                    </div>
                </div>
             `
         : ""}
        </div>
   `;
}

// ------------------------------------------------------------
// Proof
// ------------------------------------------------------------

function proofHtml() {
   const examId =
      encodeURIComponent(state.examId);

   return `
        <div class="panel">
            <div class="panel-heading">
                <h2>Proof</h2>
            </div>

            <p class="muted">
                Generate one proof paper for inspection.
            </p>

            <div class="actions">
                ${operationButton(
      "proof",
      "Run proof",
      "primary"
   )}

                ${state.proofAvailable
         ? `
                    <a
                        class="secondary"
                        href="/api/exams/${examId}/proof/html"
                        target="_blank"
                        rel="noopener noreferrer">
                        Open proof HTML ↗
                    </a>

                    ${operationButton(
            "proof-pdf",
            "Generate PDF"
         )}
                    `
         : ""}

                ${state.proofPdfAvailable
         ? `
                    <a
                        class="secondary"
                        href="/api/exams/${examId}/proof/pdf"
                        target="_blank"
                        rel="noopener noreferrer">
                        Open proof PDF ↗
                    </a>
                    `
         : ""}
            </div>
        </div>
   `;
}


// ------------------------------------------------------------
// Post-exam
// ------------------------------------------------------------

function postExamHtml() {
   const postExamPath =
      examPathFor("post-exam");
   const examId =
      encodeURIComponent(state.examId);

   const resultsPath =
      examPathFor("post-exam/results");

   const gradeLogPath =
      examPathFor("post-exam/results/output.log");

   const mailCommandPath =
      examPathFor("post-exam/mail/command.txt");

   const mailLogPath =
      examPathFor("post-exam/mail/output.log");

   const rval = `
        <div class="panel">
            <div class="panel-heading">
                <h2>OMR processing</h2>
            </div>

            <p class="muted">
                Use OMR Processor to turn scanned
                OMR sheets into the response file
                required for grading.
            </p>

            <div class="actions">
                ${state.config.omrProcessorUrl
         ? `
                    <a
                        class="secondary"
                        href="${escapeHtml(
            state.config.omrProcessorUrl
         )}"
                        target="_blank"
                        rel="noopener noreferrer">
                        Open OMR Processor ↗
                    </a>
                    `
         : `
                    <span class="muted">
                        OMR Processor URL is not configured.
                    </span>
                    `}
            </div>
        </div>

        <div class="panel">
            <div class="panel-heading">
                <h2>Grading</h2>
            </div>

            <p class="muted">
                Select the response file produced by OMR
                processing, then run McqGrader.
            </p>

            <div class="field">
                <label
                    class="field-label"
                    for="responsesFile">
                    Responses file
                </label>

                <div class="field-control">
                    <input
                        id="responsesFile"
                        type="text"
                        value="${escapeHtml(
            state.responsesFile
         )}"
                        placeholder="responses.txt">

                    <button
                        class="secondary"
                        type="button"
                        data-action="browse-asset"
                        data-field="responsesFile"
                        data-kind="file">
                        Browse…
                    </button>
                </div>
            </div>

            <div class="actions">
                <button
                    class="primary"
                    type="button"
                    data-action="grade">
                    Run McqGrader
                </button>
            </div>

            ${state.gradingAvailable || state.gradingOutputExists
         ? `
                 <div
                     class="status success"
                     role="status"
                     aria-live="polite">

                     <strong>
                          ${state.gradingAvailable ? "McqGrader completed successfully." : "McqGrader was already run."}
                     </strong>

                     <p>
                         The grade summary and individual
                         student feedback files are available
                         for inspection.
                     </p>

                     <p>
                         Grade summary and log:
                         <br>
                         <code>${escapeHtml(
            gradeLogPath
         )}</code>
                     </p>
                     <div class="actions">
                         <a
                             class="secondary"
                             href="/api/exams/${examId}/grade/output.log">
                             Download grade summary and log
                         </a>
                     </div>
                     <br/>
                     <p>
                         Individual student feedback files:
                         <br>
                         <code>${escapeHtml(
            resultsPath
         )}</code>
                     </p>
                 </div>
                 `
         : ""}
        </div>

        <div class="panel">
            <div class="panel-heading">
                <h2>Student feedback</h2>
            </div>

            <p class="muted">
                The IdMap file maps each Student ID to the
                university email name, without the
                @domain suffix. MailMan combines this name
                with the configured domain and matches each
                student ID to the feedback generated by
                McqGrader.
            </p>

            <!-- TEST MODE NOTE — restore this block when MailmanService.cs is
                 returned to preview-only mode:
            <div class="status"
                 role="note">
                <strong>Testing mode:</strong>
                Previewing the MailMan command prints the
                proposed invocation to the server console
                and saves it to the exam folder. It does
                not execute MailMan or send email.
            </div>
            <br/>
            -->

            <div class="status"
                 role="alert">
                <strong>Live MailMan mode:</strong>
                Running MailMan will execute the command and may send feedback
                emails to students. Check the IdMap file and feedback files
                carefully before proceeding.
            </div>
            <br/>

            <div class="field">
                <label
                    class="field-label"
                    for="idMapFile">
                    IdMap file
                </label>

                <div class="field-control">
                    <input
                        id="idMapFile"
                        type="text"
                        value="${escapeHtml(
            state.idMapFile
         )}"
                        placeholder="IdMap.txt">

                    <button
                        class="secondary"
                        type="button"
                        data-action="browse-asset"
                        data-field="idMapFile"
                        data-kind="file">
                        Browse…
                    </button>
                </div>
            </div>

            <!-- TEST MODE BUTTON — restore this button when MailmanService.cs
                 is returned to preview-only mode:
            <div class="actions">
                <button
                    class="primary"
                    type="button"
                    data-action="mail"
                    ${state.gradingAvailable || state.gradingOutputExists ? "" : "disabled"}>
                    Preview MailMan command
                </button>
            </div>
            -->

            <div class="actions">
                ${operationButton(
            "mail",
            "Run MailMan and send feedback",
            "primary",
            !(state.gradingAvailable || state.gradingOutputExists)
         )}
            </div>

            ${state.mailAvailable
         ? `
                 <div
                     class="status success"
                     role="status"
                     aria-live="polite">

                     <strong>
                         MailMan completed successfully.
                     </strong>

                     <p>
                         The command used is saved here:
                         <br>
                         <code>${escapeHtml(
            mailCommandPath
         )}</code>
                     </p>

                     <p>
                         Execution log:
                         <br>
                         <code>${escapeHtml(
            mailLogPath
         )}</code>
                     </p>

                     <!-- TEST MODE RESULT — restore this message when the
                          backend is in preview-only mode:
                     <p>
                         <strong>
                             MailMan was not executed.
                             No email was sent.
                         </strong>
                     </p>
                     -->
                 </div>

                 <!-- TEST MODE RESULT PANEL — restore this wording if the
                      backend is in preview-only mode:
                 <div class="status success" role="status">
                     <strong>MailMan command prepared.</strong>
                     <p>The command was prepared and saved here:</p>
                     <code>${escapeHtml(mailCommandPath)}</code>
                     <p>Preview log:</p>
                     <code>${escapeHtml(mailLogPath)}</code>
                     <p><strong>MailMan was not executed. No email was sent.</strong></p>
                 </div>
                 -->
                 `
         : ""}
        </div>
   `;

   return rval;
}

// ------------------------------------------------------------
// Error page
// ------------------------------------------------------------

export function renderError(error) {
   const app =
      document.querySelector("#app");

   app.innerHTML = `
      <section class="page">
        <div class="panel">
          <h2>Unable to open Dividni</h2>

          <p class="muted">
             ${escapeHtml(error.message)}
             <br/>
             (Is the backend running? Check the console for details.)
          </p>
        </div>
      </section>
   `;
}