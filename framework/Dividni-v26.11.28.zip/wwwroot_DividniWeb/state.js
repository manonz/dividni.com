"use strict";

export const state = {
   exams: [],
   exam: null,
   examId: null,
   examPath: "",

   section: "preparation",

   composition: [],

   dirty: false,
   saving: false,

   busyOperation: null,

   status: "",
   statusError: false,

   proofAvailable: false,
   proofPdfAvailable: false,
   proofOutputExists: false,

   productionAvailable: false,
   productionPaperCount: 0,

   productionPdfAvailable: false,
   productionPdfCount: 0,
   productionPageCount: 0,

   productionOutputExists: false,
   productionZipAvailable: false,
   productionPackageAvailable: false,
   productionCombinedPdfAvailable: false,
   productionPackageError: "",

   postExamExists: false,

   savedManifest: null,

   responsesFile: "",
   gradingAvailable: false,
   gradingExitCode: 0,
   gradingOutputExists: false,

   idMapFile: "",
   mailAvailable: false,
   mailExitCode: 0,
   mailCommand: "",

   config: {
      omrProcessorUrl: "",
      settingsFileExists: false,
      settingsFilePath: ""
   }
};