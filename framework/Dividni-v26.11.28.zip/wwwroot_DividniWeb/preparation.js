"use strict";

import { state } from "./state.js";
import {
   escapeHtml,
   linesText
} from "./utils.js";

import { getAssets } from "./api.js";


// ------------------------------------------------------------
// Preparation rendering
// ------------------------------------------------------------

export function preparationHtml() {
   const composition =
      state.composition
         .map(compositionRowHtml)
         .join("");

   return `

        <div
            id="manifestForm">

            <div class="panel">

                <div class="panel-heading">

                    <h2>
                        Exam folder
                    </h2>

                </div>

                <p>
                    <code>${escapeHtml(
      state.examPath
   )}</code>
                </p>

                <p class="muted">
                    Place exam assets in this folder.
                </p>

            </div>


            <div class="panel">

                <div class="panel-heading">

                    <h2>
                        Exam information
                    </h2>

                </div>

                <div class="info-grid">

                    ${manifestField(
      "Course code",
      "courseCode",
      state.exam.courseCode
   )}

                    ${manifestField(
      "Date",
      "date",
      state.exam.date
   )}

                    <div class="field">

                        <label
                            class="field-label"
                            for="startId">
                            Start ID
                        </label>

                        <input
                            id="startId"
                            name="startId"
                            type="text"
                            inputmode="numeric"
                            pattern="[0-9]*"
                            maxlength="20"
                            value="${escapeHtml(
      String(state.exam.startId ?? "")
   )}"
                            data-manifest-field>

                    </div>

                    ${manifestField(
      "Course information",
      "courseInfo",
      state.exam.courseInfo,
      true
   )}

                </div>

            </div>


            <div class="panel">

                <div class="panel-heading">

                    <h2>
                        Special files
                    </h2>

                </div>

                <div class="info-grid">

                    ${manifestField(
      "Cover page",
      "prologue",
      state.exam.prologue,
      false,
      "html"
   )}

                    ${manifestField(
      "OMR sheet",
      "omr",
      state.exam.omr,
      false,
      "svg"
   )}

                    ${manifestField(
      "CSS",
      "css",
      state.exam.css,
      false,
      "css"
   )}

                    ${manifestField(
      "Epilogue",
      "epilogue",
      state.exam.epilogue,
      false,
      "html"
   )}


                    <div class="field full">

                        <label
                            class="field-label"
                            for="math">
                            Math engine
                        </label>

                        <select
                            id="math"
                            name="math"
                            data-manifest-field>

                            <option
                                value=""
                                ${!state.exam.math
         ? "selected"
         : ""
      }>
                                Default
                            </option>

                            <option
                                value="katex"
                                ${state.exam.math === "katex"
         ? "selected"
         : ""
      }>
                                KaTeX
                            </option>

                            <option
                                value="mathjax"
                                ${state.exam.math === "mathjax"
         ? "selected"
         : ""
      }>
                                MathJax
                            </option>

                        </select>

                    </div>

                </div>

            </div>


            <div class="panel">

                <div class="panel-heading">

                    <h2>
                        References
                    </h2>

                </div>

                <label class="field">

                    <span class="field-label">
                        External library references
                    </span>

                    <textarea
                        name="references"
                        data-manifest-field
                        rows="4"
                        placeholder="One filename per line"
                    >${escapeHtml(
         linesText(
            state.exam.references
         )
      )}</textarea>

                </label>

                <p class="muted small">
                    References are literal filenames;
                    wildcards are not used here.
                </p>

            </div>


            <div class="panel">

                <div class="panel-heading">

                    <h2>
                        Libraries
                    </h2>

                </div>

                <label class="field">

                    <span class="field-label">
                        Internal library references
                    </span>

                    <textarea
                        name="library"
                        data-manifest-field
                        rows="4"
                        placeholder="One filename per line"
                    >${escapeHtml(
         linesText(
            state.exam.library
         )
      )}</textarea>

                </label>

                <p class="muted small">
                    Libraries are literal filenames;
                    wildcards are not used here.
                </p>

            </div>


            <div class="panel">

                <div class="panel-heading">

                    <h2>
                        Composition
                    </h2>

                    <span class="muted">
                        ${state.composition.length} entries
                    </span>

                </div>

                <div class="composition-list">

                    ${composition ||
      `
                            <div class="empty">
                                Composition is empty.
                            </div>
                        `
      }

                </div>

                <div class="actions">

                    <button
                        class="secondary"
                        type="button"
                        data-action="add">
                        Add file / pattern
                    </button>

                    <button
                        class="secondary"
                        type="button"
                        data-action="browse-asset"
                        data-field="composition"
                        data-kind="composition">
                        Browse file
                    </button>

                    <button
                        class="secondary"
                        type="button"
                        data-action="add"
                        data-value=".xx">
                        Add Pagebreak
                    </button>

                    <button
                        class="secondary"
                        type="button"
                        data-action="add-missing-generators">
                        Add missing generators
                    </button>

                </div>

                <p class="muted small">
                    Composition entries may be literal
                    filenames or wildcard patterns.
                </p>

            </div>


            <div class="panel">

                <div class="actions">

                    <button
                        class="primary"
                        type="button"
                        data-action="save"
                        ${state.saving ||
         !state.dirty
         ? "disabled"
         : ""
      }>

                        ${state.saving
         ? "Saving…"
         : "Save changes"
      }

                    </button>

                    <span
                        id="unsavedChanges"
                        class="muted"
                        ${state.dirty ? "" : "hidden"}>
                        Unsaved changes
                    </span>

                </div>

            </div>

        </div>
    `;
}


function manifestField(
   label,
   name,
   value,
   full = false,
   browseKind = null) {

   const browseButton =
      browseKind
         ? `
                <button
                    class="secondary"
                    type="button"
                    data-action="browse-asset"
                    data-field="${escapeHtml(name)}"
                    data-kind="${escapeHtml(browseKind)}">
                    Browse…
                </button>
              `
         : "";

   return `
        <div
            class="field ${full ? "full" : ""}">

            <label
                class="field-label"
                for="${escapeHtml(name)}">
                ${escapeHtml(label)}
            </label>

            <div class="field-control">

                <input
                    id="${escapeHtml(name)}"
                    name="${escapeHtml(name)}"
                    value="${escapeHtml(value || "")}"
                    data-manifest-field>

                ${browseButton}

            </div>

        </div>
    `;
}


// ------------------------------------------------------------
// Asset discovery
// ------------------------------------------------------------

export async function addMissingGenerators(render) {
   preserveManifestDraft();

   try {
      const assets =
         await getAssets(state.examId);

      const additions =
         assets.cs.filter(
            file =>
               !state.composition.some(
                  item =>
                     compositionRepresents(
                        item,
                        file
                     )
               )
         );

      if (additions.length === 0) {
         state.status =
            "All .cs files are already represented in the composition.";

         state.statusError =
            false;

         render();

         return;
      }

      state.composition.push(
         ...additions
      );

      state.exam.composition = [
         ...state.composition
      ];

      markDirty();

      state.status =
         `Added ${additions.length} missing generator` +
         `${additions.length === 1 ? "" : "s"}.`;

      render();

   } catch (error) {
      window.alert(
         `Could not inspect the exam folder.\n\n${error.message}`
      );
   }
}


function compositionRepresents(
   item,
   filename) {

   if (item === filename) {
      return true;
   }

   if (
      !item.includes("*") &&
      !item.includes("?")
   ) {
      return false;
   }

   return wildcardMatch(
      item,
      filename
   );
}


function wildcardMatch(
   pattern,
   value) {

   const escaped =
      pattern.replace(
         /[.+^${}()|[\]\\]/g,
         "\\$&"
      );

   const regexText =
      escaped
         .replaceAll("*", ".*")
         .replaceAll("?", ".");

   return new RegExp(
      `^${regexText}$`,
      "i"
   ).test(value);
}


// ------------------------------------------------------------
// Asset picker
// ------------------------------------------------------------

export async function openAssetPicker(
   field,
   kind) {

   preserveManifestDraft();

   try {
      const assets =
         await getAssets(state.examId);

      const files =
         assetFilesForKind(
            assets,
            kind,
            field
         );

      const titles = {
         prologue: "Select cover page",
         omr: "Select OMR sheet",
         css: "Select CSS file",
         epilogue: "Select epilogue",
         html: "Select HTML file",
         svg: "Select SVG file",
         composition: "Select composition file",
         file: "Select file",
         responsesFile: "Select responses file",
         idMapFile: "Select IdMap file"
      };

      const dialog =
         document.querySelector(
            "#assetDialog"
         );

      const title =
         document.querySelector(
            "#assetDialogTitle"
         );

      const list =
         document.querySelector(
            "#assetDialogList"
         );

      title.textContent =
         titles[field] ||
         titles[kind] ||
         "Select file";

      if (files.length === 0) {
         list.innerHTML = `
                <div class="empty">
                    No matching files found
                    in the exam folder.
                </div>
            `;
      } else {
         list.innerHTML =
            files
               .map(
                  file => `
                            <button
                                class="asset-option"
                                type="button"
                                data-action="select-asset"
                                data-field="${escapeHtml(field)}"
                                data-value="${escapeHtml(file)}">
                                ${escapeHtml(file)}
                            </button>
                        `
               )
               .join("");
      }

      dialog.showModal();

   } catch (error) {
      window.alert(
         `Could not inspect the exam folder.\n\n${error.message}`
      );
   }
}


function assetFilesForKind(
   assets,
   kind,
   field) {

   switch (kind) {

      case "html":
         return assets.html || [];

      case "svg":
         return assets.svg || [];

      case "css":
         return assets.css || [];

      case "composition":
         return [
            ...(assets.html || []),
            ...(assets.cs || [])
         ].sort(
            (a, b) =>
               a.localeCompare(
                  b,
                  undefined,
                  { sensitivity: "base" }
               )
         );

      case "file": {
         const files =
            assets.files || [];

         if (field === "responsesFile") {
            return files.filter(
               file => /\.txt$/i.test(file)
            );
         }

         if (field === "idMapFile") {
            return files.filter(
               file => /\.(txt|csv)$/i.test(file)
            );
         }

         return files;
      }

      default:
         return [];
   }
}

export function selectAsset(
   field,
   value,
   render) {

   if (!state.exam) {
      return;
   }

   if (field === "composition") {

      if (state.composition.includes(value)) {

         state.status =
            `${value} is already in the composition.`;

         state.statusError = false;

      } else {

         state.composition.push(value);

         state.exam.composition = [
            ...state.composition
         ];

         markDirty();
      }

   } else if (field === "responsesFile") {

      state.responsesFile = value;
      state.status = "";
      state.statusError = false;

   } else if (field === "idMapFile") {

      state.idMapFile = value;
      state.status = "";
      state.statusError = false;

   } else {

      state.exam[field] = value;

      markDirty();
   }

   closeAssetPicker();

   render();
}


export function closeAssetPicker() {
   const dialog =
      document.querySelector(
         "#assetDialog"
      );

   if (
      dialog &&
      dialog.open
   ) {
      dialog.close();
   }
}


// ------------------------------------------------------------
// Manifest handling
// ------------------------------------------------------------

export function captureManifestForm() {
   if (!state.exam) {
      return null;
   }

   const container =
      document.querySelector("#manifestForm");

   if (!container) {
      return {
         courseCode:
            state.exam.courseCode || "",

         courseInfo:
            state.exam.courseInfo || "",

         date:
            state.exam.date || "",

         startId:
            String(state.exam.startId ?? ""),

         prologue:
            state.exam.prologue || "",

         omr:
            state.exam.omr || "",

         css:
            state.exam.css || "",

         epilogue:
            state.exam.epilogue || "",

         math:
            state.exam.math || "",

         references: [
            ...(state.exam.references || [])
         ],

         library: [
            ...(state.exam.library || [])
         ],

         composition: [
            ...state.composition
         ]
      };
   }

   const value =
      name => {
         const control =
            container.querySelector(
               `[name="${name}"]`
            );

         return String(
            control?.value ?? ""
         ).trim();
      };

   const lines =
      name =>
         value(name)
            .split(/\r?\n/)
            .map(
               item => item.trim()
            )
            .filter(
               item => item.length > 0
            );

   return {
      courseCode:
         value("courseCode"),

      courseInfo:
         value("courseInfo"),

      date:
         value("date"),

      startId:
         value("startId"),

      prologue:
         value("prologue"),

      omr:
         value("omr"),

      css:
         value("css"),

      epilogue:
         value("epilogue"),

      math:
         value("math"),

      references:
         lines("references"),

      library:
         lines("library"),

      composition: [
         ...state.composition
      ]
   };
}


export function preserveManifestDraft() {
   const manifest =
      captureManifestForm();

   if (!manifest) {
      return;
   }

   state.exam = {
      ...state.exam,

      courseCode:
         manifest.courseCode,

      courseInfo:
         manifest.courseInfo,

      date:
         manifest.date,

      startId:
         manifest.startId,

      prologue:
         manifest.prologue,

      omr:
         manifest.omr,

      css:
         manifest.css,

      epilogue:
         manifest.epilogue,

      math:
         manifest.math,

      references: [
         ...manifest.references
      ],

      library: [
         ...manifest.library
      ],

      composition: [
         ...manifest.composition
      ]
   };

   state.composition = [
      ...manifest.composition
   ];
}


export function validateManifest(
   manifest) {

   if (!manifest.courseCode) {
      return "Course code is required.";
   }

   if (!manifest.courseInfo) {
      return "Course information is required.";
   }

   if (!manifest.date) {
      return "Date is required.";
   }

   const startId =
      String(manifest.startId ?? "");

   if (!/^[0-9]{1,20}$/.test(startId)) {
      return (
         "Start ID must be a positive integer " +
         "containing at most 20 digits."
      );
   }

   const startIdValue =
      BigInt(startId);

   if (
      startIdValue < 1n ||
      startIdValue > 18446744073709551615n
   ) {
      return (
         "Start ID must be between 1 and " +
         "18446744073709551615."
      );
   }


   const specialFiles = [
      [
         "Cover page",
         manifest.prologue,
         ".html"
      ],
      [
         "OMR sheet",
         manifest.omr,
         ".svg"
      ],
      [
         "CSS",
         manifest.css,
         ".css"
      ],
      [
         "Epilogue",
         manifest.epilogue,
         ".html"
      ]
   ];


   for (const [
      label,
      value,
      extension
   ] of specialFiles) {

      if (
         value &&
         !value
            .toLowerCase()
            .endsWith(extension)
      ) {
         return (
            `${label} must end in ${extension}.`
         );
      }

      if (
         value &&
         (
            value.includes("/") ||
            value.includes("\\")
         )
      ) {
         return (
            `${label} must be a filename, not a path.`
         );
      }
   }


   for (const item of manifest.composition) {

      if (!isValidCompositionEntry(item)) {
         return (
            `Invalid composition entry: ${item}\n\n` +
            "Composition entries must end in .html " +
            "or .cs, or be exactly .xx."
         );
      }
   }


   for (const item of [
      ...manifest.references,
      ...manifest.library
   ]) {

      if (
         item.includes("*") ||
         item.includes("?") ||
         item.includes("/") ||
         item.includes("\\")
      ) {
         return (
            `Invalid reference/library entry: ${item}\n\n` +
            "References and libraries must be literal filenames."
         );
      }
   }


   if (
      manifest.math &&
      manifest.math !== "katex" &&
      manifest.math !== "mathjax"
   ) {
      return (
         "Math engine must be blank, katex, or mathjax."
      );
   }

   return null;
}


// ------------------------------------------------------------
// Composition
// ------------------------------------------------------------

function isValidCompositionEntry(
   value) {

   if (!value) {
      return false;
   }

   if (value === ".xx") {
      return true;
   }

   if (
      value.includes("/") ||
      value.includes("\\")
   ) {
      return false;
   }

   return (
      /\.html$/i.test(value) ||
      /\.cs$/i.test(value)
   );
}


function compositionRowHtml(
   item,
   index) {

   return `
        <div class="file-row">

            <div class="file-main">

                <span class="badge">
                    ${compositionType(item)}
                </span>

                <span class="file-name">
                    ${escapeHtml(item)}
                </span>

            </div>

            <div class="file-actions">

                <button
                    class="icon-button"
                    type="button"
                    title="Move up"
                    aria-label="Move up"
                    data-action="move"
                    data-index="${index}"
                    data-delta="-1"
                    ${index === 0 ? "disabled" : ""}>
                    ↑
                </button>

                <button
                    class="icon-button"
                    type="button"
                    title="Move down"
                    aria-label="Move down"
                    data-action="move"
                    data-index="${index}"
                    data-delta="1"
                    ${index ===
         state.composition.length - 1
         ? "disabled"
         : ""
      }>
                    ↓
                </button>

                <button
                    class="icon-button"
                    type="button"
                    title="Remove"
                    aria-label="Remove"
                    data-action="remove"
                    data-index="${index}">
                    ×
                </button>

            </div>

        </div>
    `;
}


function compositionType(item) {
   if (item === ".xx") {
      return "Page break";
   }

   if (/\.html$/i.test(item)) {
      return "HTML";
   }

   if (/\.cs$/i.test(item)) {
      return "Generator";
   }

   return "Other";
}


export function markDirty() {
   state.dirty = true;
   state.status = "";
   state.statusError = false;

   const saveButton =
      document.querySelector(
         '[data-action="save"]'
      );

   if (saveButton) {
      saveButton.disabled = false;
   }

   const dirtyLabel =
      document.querySelector(
         "#unsavedChanges"
      );

   if (dirtyLabel) {
      dirtyLabel.hidden = false;
   }
}


export function moveComposition(
   index,
   delta,
   render) {

   preserveManifestDraft();

   const target =
      index + delta;

   if (
      target < 0 ||
      target >= state.composition.length
   ) {
      return;
   }

   [
      state.composition[index],
      state.composition[target]
   ] = [
         state.composition[target],
         state.composition[index]
      ];

   state.exam.composition = [
      ...state.composition
   ];

   markDirty();

   render();
}


export function removeComposition(
   index,
   render) {

   preserveManifestDraft();

   state.composition.splice(
      index,
      1
   );

   state.exam.composition = [
      ...state.composition
   ];

   markDirty();

   render();
}


function addPageBreak(render) {
   appendCompositionItem(".xx", render);
}


function appendCompositionItem(item, render) {
   state.composition.push(item);

   state.exam.composition = [
      ...state.composition
   ];

   markDirty();
   render();
}


export function addComposition(
   render,
   initialValue = undefined) {

   preserveManifestDraft();

   const value =
      initialValue === undefined
         ? window.prompt(
            "Enter a .html file, .cs file, " +
            "wildcard pattern, or .xx:"
         )
         : initialValue;

   if (value === null) {
      return;
   }

   const item = value.trim();

   if (!isValidCompositionEntry(item)) {
      window.alert(
         "Composition entries must end in .html " +
         "or .cs, or be exactly .xx.\n\n" +
         "Path separators are not allowed."
      );

      return;
   }

   if (item === ".xx") {
      addPageBreak(render);
      return;
   }

   appendCompositionItem(item, render);
}