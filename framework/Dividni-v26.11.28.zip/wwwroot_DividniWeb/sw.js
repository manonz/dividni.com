const CACHE_NAME = "dividni-cache-v1";

const ASSETS_TO_CACHE = [
   "api.js",
   "app.js",
   "Dividni-Full-Logo-Black.svg",
   "Dividni-Logo.svg",
   "DividniWeb.settings.example.json",
   "index.html",
   "manifest.json",
   "preparation.js",
   "rendering.js",
   "state.js",
   "style.css",
   "utils.js",
   "workflow.js" 
];


self.addEventListener("install", event => {

   event.waitUntil(

      caches.open(CACHE_NAME)
         .then(cache => cache.addAll(ASSETS_TO_CACHE))
         .then(() => self.skipWaiting())

   );

});


self.addEventListener("activate", event => {

   event.waitUntil(

      caches.keys()
         .then(cacheNames => {

            return Promise.all(

               cacheNames.map(cache => {

                  if (cache !== CACHE_NAME)
                     return caches.delete(cache);

               })

            );

         })
         .then(() => self.clients.claim())

   );

});


self.addEventListener("fetch", event => {

   if (!event.request.url.startsWith(self.location.origin))
      return;

   event.respondWith(

      caches.match(event.request)
         .then(cachedResponse => {

            return cachedResponse ||
                   fetch(event.request);

         })

   );

});