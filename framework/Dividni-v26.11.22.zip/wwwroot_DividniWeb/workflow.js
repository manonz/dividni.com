"use strict";

import {
   getJson,
   postJson
} from "./api.js";

import { state } from "./state.js";

import {
   renderExam,
   renderExams,
   renderError
} from "./rendering.js";

import {
   captureManifestForm,
   validateManifest
} from "./preparation.js";


// ------------------------------------------------------------
// Loading
// ------------------------------------------------------------

export async function loadConfig() {
   try {

      state.config =
         await getJson("/config");

   } catch (error) {

      console.error(
         "Could not load configuration.",
         error
      );
   }
}


export async function loadVersion() {
   try {

      return await getJson("/version");

   } catch (error) {

      console.error(
         "Could not load version.",
         error
      );

      return null;
   }
}


export async function loadExams() {
   state.exams =
      await getJson("/exams");
}


export async function loadExam(id) {
   const [exam, location, outputs] =
      await Promise.all([
         getJson(
            `/exams/${encodeURIComponent(id)}`
         ),
         getJson(
            `/exams/${encodeURIComponent(id)}/path`
         ),
         getJson(
            `/exams/${encodeURIComponent(id)}/outputs`
         )
      ]);

   state.exam = exam;
   state.savedManifest = copyManifest(exam);
   state.examId = id;
   state.examPath = location.path;
   state.composition = [...(exam.composition || [])];
   state.dirty = false;
   state.saving = false;
   state.status = "";
   state.statusError = false;

   // A proof can be inspected immediately after generating it, but on
   // reopening we do not pretend the previous proof is currently displayed.
   state.proofAvailable = false;
   state.proofPdfAvailable = false;

   applyOutputStatus(outputs);

   state.responsesFile = "";
   state.gradingAvailable = false;
   state.gradingExitCode = 0;
   state.idMapFile = "";
   state.mailAvailable = false;
   state.mailExitCode = 0;
   state.mailCommand = "";
}


function copyManifest(manifest) {
   return {
      ...manifest,
      references: [...(manifest.references || [])],
      library: [...(manifest.library || [])],
      composition: [...(manifest.composition || [])]
   };
}


function manifestHasChanged(draft, saved) {
   if (!saved) {
      return true;
   }

   const scalarFields = [
      "startId",
      "courseCode",
      "courseInfo",
      "date",
      "prologue",
      "omr",
      "css",
      "epilogue",
      "math"
   ];

   for (const field of scalarFields) {
      const left = String(draft?.[field] ?? "").trim();
      const right = String(saved?.[field] ?? "").trim();
      if (left !== right) {
         return true;
      }
   }

   for (const field of ["references", "library", "composition"]) {
      const left = (draft?.[field] || []).map(value => String(value).trim());
      const right = (saved?.[field] || []).map(value => String(value).trim());
      if (left.length !== right.length ||
         left.some((value, index) => value !== right[index])) {
         return true;
      }
   }

   return false;
}


function applyOutputStatus(outputs) {
   const htmlCount = Number(outputs?.productionHtmlCount || 0);
   const pdfCount = Number(outputs?.productionPdfCount || 0);

   state.productionAvailable = htmlCount > 0;
   state.productionPaperCount = htmlCount;
   state.productionPdfAvailable = pdfCount > 0;
   state.productionPdfCount = pdfCount;
   state.productionPageCount = 0;

   state.productionZipAvailable =
      outputs?.individualPdfsZipAvailable === true;
   state.productionCombinedPdfAvailable =
      outputs?.combinedPdfAvailable === true;
   state.productionPackageAvailable =
      state.productionZipAvailable || state.productionCombinedPdfAvailable;

   state.productionPackageError =
      state.productionZipAvailable && !state.productionCombinedPdfAvailable
         ? "The individual PDFs ZIP exists, but the combined PDF is not present. The previous merge may have failed."
         : "";

   state.proofAvailable = outputs?.proofHtmlAvailable === true;
   state.proofPdfAvailable = outputs?.proofPdfAvailable === true;

   state.proofOutputExists = outputs?.proofExists === true;
   state.productionOutputExists = outputs?.productionExists === true;
   state.postExamExists = outputs?.postExamExists === true;

   state.gradingOutputExists = outputs?.mcqGraderOutputLogExists === true;
}


export async function refreshOutputStatus() {
   if (!state.examId) {
      return;
   }

   const outputs = await getJson(
      `/exams/${encodeURIComponent(state.examId)}/outputs`
   );

   applyOutputStatus(outputs);
}


export async function openExam(id) {
   try {

      await loadExam(id);

      state.section =
         "preparation";

      renderExam();

   } catch (error) {

      console.error(
         "Could not open exam:",
         error
      );

      renderError(error);
   }
}


// ------------------------------------------------------------
// Manifest saving
// ------------------------------------------------------------

export async function saveManifest() {
   if (
      state.saving ||
      !state.exam ||
      !state.dirty
   ) {
      return true;
   }

   const manifest = captureManifestForm();

   // Some older forms do not expose StartId as an editable field. Preserve the
   // saved value if the form omitted it rather than sending zero accidentally.
   if (manifest.startId === undefined || manifest.startId === null || manifest.startId === "") {
      manifest.startId = state.savedManifest?.startId ?? state.exam.startId;
   }

   const validationError = validateManifest(manifest);
   if (validationError) {
      state.status = validationError;
      state.statusError = true;
      renderExam();
      return false;
   }

   const examId = state.examId;

   try {
      // Re-read the filesystem immediately before deciding what to do. This
      // handles the user manually deleting post-exam/proof/production folders.
      await refreshOutputStatus();
   } catch (error) {
      state.status = `Could not refresh exam output status: ${error.message}`;
      state.statusError = true;
      renderExam();
      return false;
   }

   const saved = state.savedManifest || state.exam;
   const changed = manifestHasChanged(manifest, saved);

   if (!changed) {
      state.exam = copyManifest(manifest);
      state.savedManifest = copyManifest(manifest);
      state.dirty = false;
      state.status = "No manifest changes to save.";
      state.statusError = false;
      renderExam();
      return true;
   }

   if (state.postExamExists) {
      state.status =
         "The manifest is locked because the post-exam directory exists. " +
         "Back up any results you need, manually delete " +
         `${state.examPath}/post-exam, then switch sections or reopen the exam before trying again.`;
      state.statusError = true;
      renderExam();
      return false;
   }

   const invalidatesOutput =
      state.proofOutputExists || state.productionOutputExists;

   if (invalidatesOutput && !window.confirm(
      "Saving these manifest changes will delete the entire proof and production directories, " +
      "including generated HTML, PDFs, ZIP files and temporary merge files. The exam assets " +
      "and manifest will be retained. Continue?"
   )) {
      state.status = "Save cancelled. Existing proof and production outputs were kept.";
      state.statusError = false;
      renderExam();
      return false;
   }

   state.saving = true;
   state.status = "Saving changes…";
   state.statusError = false;
   renderExam();

   try {
      const result = await postJson(
         `/exams/${encodeURIComponent(examId)}/manifest`,
         manifest
      );

      state.exam = result;
      state.savedManifest = copyManifest(result);
      state.composition = [...(result.composition || [])];
      state.dirty = false;
      state.saving = false;

      state.proofAvailable = false;
      state.proofPdfAvailable = false;
      state.gradingAvailable = false;
      state.gradingExitCode = 0;
      state.mailAvailable = false;
      state.mailExitCode = 0;
      state.mailCommand = "";

      await refreshOutputStatus();
      await loadExams();

      state.status = invalidatesOutput
         ? "Changes saved. Proof and production outputs were deleted."
         : "Changes saved.";
      state.statusError = false;

      updateExamSummary(examId, result);
      renderExam();
      return true;

   } catch (error) {
      state.saving = false;

      // The server is authoritative. If post-exam processing appeared since
      // our refresh, the server rejects the update; refresh our view as well.
      try {
         await refreshOutputStatus();
      } catch {
         // Keep the original save error for the user.
      }

      state.status = error.message;
      state.statusError = true;
      renderExam();
      return false;
   }
}

function updateExamSummary(
   examId,
   exam) {

   const summary =
      state.exams.find(
         item => item.id === examId
      );

   if (!summary) {
      return;
   }

   summary.courseCode =
      exam.courseCode;

   summary.courseInfo =
      exam.courseInfo;

   summary.date =
      exam.date;
}


// ------------------------------------------------------------
// Proof
// ------------------------------------------------------------

export async function runProof() {
   // Proof must always use the saved manifest.
   if (state.dirty) {

      const saved =
         await saveManifest();

      if (!saved) {
         return;
      }
   }

   state.status =
      "Running McqTestGen proof…";

   state.statusError =
      false;

   state.proofAvailable =
      false;

   state.proofPdfAvailable =
      false;

   renderExam();

   try {

      const result =
         await postJson(
            `/exams/${encodeURIComponent(
               state.examId
            )}/proof`,
            {}
         );

      if (!result.success) {

         state.status =
            `Proof failed (exit code ${result.exitCode}).`;

         state.statusError =
            true;

         renderExam();

         return;
      }

      state.proofAvailable =
         true;
      state.proofOutputExists = true;

      state.status =
         "Proof completed — 1 HTML paper; answer keys available.";

      state.statusError =
         false;

      renderExam();

   } catch (error) {

      state.status =
         error.message;

      state.statusError =
         true;

      renderExam();
   }
}


export async function runProofPdf() {
   state.status =
      "Converting proof HTML to PDF…";

   state.statusError =
      false;

   state.proofPdfAvailable =
      false;

   renderExam();

   try {

      const result =
         await postJson(
            `/exams/${encodeURIComponent(
               state.examId
            )}/proof-pdf`,
            {}
         );

      state.proofPdfAvailable =
         true;

      state.status =
         `PDF created — ${result.pdfCount} paper` +
         `${result.pdfCount === 1 ? "" : "s"}, ` +
         `${result.pageCount} pages.`;

      state.statusError =
         false;

      renderExam();

   } catch (error) {

      state.status =
         error.message;

      state.statusError =
         true;

      renderExam();
   }
}


// ------------------------------------------------------------
// Production
// ------------------------------------------------------------

export async function runProduction(
   paperCount) {

   const count =
      Number.parseInt(
         paperCount,
         10
      );

   if (
      !Number.isInteger(count) ||
      count < 1
   ) {

      state.status =
         "Paper count must be at least 1.";

      state.statusError =
         true;

      renderExam();

      return;
   }


   // Production must always use the saved manifest.
   if (state.dirty) {

      const saved =
         await saveManifest();

      if (!saved) {
         return;
      }
   }


   state.status =
      `Generating ${count} production paper` +
      `${count === 1 ? "" : "s"}…`;

   state.statusError =
      false;

   state.productionAvailable =
      false;

   state.productionPdfAvailable =
      false;

   state.productionPdfCount =
      0;

   state.productionPageCount =
      0;

   state.productionPackageAvailable =
      false;

   state.gradingAvailable =
      false;

   state.gradingExitCode =
      0;

   state.mailAvailable =
      false;

   state.mailExitCode =
      0;

   renderExam();


   try {

      const result =
         await postJson(
            `/exams/${encodeURIComponent(
               state.examId
            )}/production`,
            {
               paperCount: count
            }
         );

      if (!result.success) {

         state.status =
            `Production failed (exit code ${result.exitCode}).`;

         state.statusError =
            true;

         renderExam();

         return;
      }


      state.productionAvailable =
         true;
      state.productionOutputExists = true;

      state.productionPaperCount =
         result.paperCount;


      state.status =
         `Production completed — ` +
         `${result.paperCount} HTML papers; ` +
         `answer keys available.`;

      state.statusError =
         false;

      renderExam();

   } catch (error) {

      state.status =
         error.message;

      state.statusError =
         true;

      renderExam();
   }
}


export async function runProductionPdf() {
   if (!state.productionAvailable) {
      return;
   }


   state.status =
      "Converting production papers to PDF…";

   state.statusError =
      false;

   state.productionPdfAvailable =
      false;

   state.productionPdfCount =
      0;

   state.productionPageCount =
      0;

   state.productionPackageAvailable =
      false;

   renderExam();


   try {

      const result =
         await postJson(
            `/exams/${encodeURIComponent(
               state.examId
            )}/production-pdf`,
            {}
         );


      state.productionPdfAvailable =
         true;

      state.productionPdfCount =
         result.pdfCount;

      state.productionPageCount =
         result.pageCount;


      state.status =
         `${result.pdfCount} PDFs created, ` +
         `${result.pageCount} pages each.`;

      state.statusError =
         false;

      renderExam();

   } catch (error) {

      state.status =
         error.message;

      state.statusError =
         true;

      renderExam();
   }
}

export async function runProductionPackage() {
   if (!state.productionPdfAvailable) {
      return;
   }

   state.status =
      "Creating printing-company files…";

   state.statusError = false;

   state.productionPackageAvailable = false;
   state.productionCombinedPdfAvailable = false;
   state.productionPackageError = "";

   renderExam();

   try {
      const result =
         await postJson(
            `/exams/${encodeURIComponent(
               state.examId
            )}/production-package`,
            {}
         );

      // A returned result means the ZIP was created.
      state.productionPackageAvailable = true;
      state.productionZipAvailable = true;
      state.productionOutputExists = true;

      state.productionCombinedPdfAvailable =
         result.combinedPdfSuccess === true;

      state.productionPackageError =
         result.combinedPdfError || "";

      if (state.productionCombinedPdfAvailable) {
         state.status =
            "Printing-company files are ready.";

         state.statusError = false;
      } else {
         state.status =
            "The individual PDFs ZIP is ready, " +
            "but the combined PDF could not be created. " +
            "See details below.";

         state.statusError = true;
      }

      renderExam();

   } catch (error) {
      state.productionPackageAvailable = false;
      state.productionCombinedPdfAvailable = false;
      state.productionPackageError = "";

      state.status = error.message;
      state.statusError = true;

      renderExam();
   }
}

// ------------------------------------------------------------
// Grading
// ------------------------------------------------------------

export async function runGrading(
   responsesFile) {

   const file =
      String(
         responsesFile ?? ""
      ).trim();

   if (!file) {
      state.status =
         "Enter the responses file.";

      state.statusError = true;
      renderExam();
      return;
   }

   state.responsesFile = file;

   state.gradingAvailable = false;
   state.gradingExitCode = 0;

   // Previous MailMan command preview is now stale.
   state.mailAvailable = false;
   state.mailExitCode = 0;

   state.status =
      "Running McqGrader…";

   state.statusError = false;
   renderExam();

   try {
      const result =
         await postJson(
            `/exams/${encodeURIComponent(
               state.examId
            )}/grade`,
            {
               responsesFile: file
            }
         );

      state.gradingExitCode =
         result.exitCode ?? 0;

      if (!result.success) {
         state.status =
            `McqGrader failed (exit code ${result.exitCode}).`;

         state.statusError = true;
         renderExam();
         return;
      }

      state.gradingAvailable = true;

      state.status =
         "McqGrader completed. The grade summary and " +
         "individual feedback files are available " +
         "under post-exam.";

      state.statusError = false;
      renderExam();

   } catch (error) {
      state.status = error.message;
      state.statusError = true;
      renderExam();
   }
}


// ------------------------------------------------------------
// MailMan command preview — no email is sent
// ------------------------------------------------------------

export async function runMail(idMapFile) {
   if (
      !state.gradingAvailable &&
      !state.gradingOutputExists
   ) {
      state.status =
         "Run McqGrader successfully before preparing the MailMan command.";
      state.statusError = true;
      renderExam();
      return;
   }

   const file = String(idMapFile ?? "").trim();

   if (!file) {
      state.status = "Enter the IdMap file.";
      state.statusError = true;
      renderExam();
      return;
   }

   state.idMapFile = file;
   state.mailAvailable = false;
   state.mailExitCode = 0;
   state.mailCommand = "";

   // Use the same busy state as the other long-running operations.
   state.busyOperation = "mail";
   state.status = "Running MailMan and sending feedback…";
   state.statusError = false;
   renderExam();

   try {
      const result = await postJson(
         `/exams/${encodeURIComponent(state.examId)}/mail`,
         { idMapFile: file }
      );

      state.mailExitCode = result.exitCode ?? 0;

      if (!result.success) {
         state.status =
            `MailMan failed (exit code ${result.exitCode ?? "unknown"}): ` +
            (result.error || "No error details were returned.");
         state.statusError = true;
         return;
      }

      state.mailCommand = result.command || "";
      state.mailAvailable = true;
      state.status = "";
      state.statusError = false;

   } catch (error) {
      state.status = error.message;
      state.statusError = true;

   } finally {
      // Always remove the spinner, including after errors or early returns.
      state.busyOperation = null;
      renderExam();
   }
}

// ------------------------------------------------------------
// Navigation
// ------------------------------------------------------------

export async function changeSection(
   section) {

   if (
      state.dirty &&
      !window.confirm(
         "Discard unsaved changes?"
      )
   ) {
      return;
   }

   if (state.dirty) {
      await loadExam(state.examId);
   } else {
      try {
         await refreshOutputStatus();
      } catch (error) {
         state.status = `Could not refresh output status: ${error.message}`;
         state.statusError = true;
      }
   }

   state.section =
      section;

   state.status =
      "";

   state.statusError =
      false;

   renderExam();
}


export async function closeExam() {
   if (
      state.dirty &&
      !window.confirm(
         "Discard unsaved changes?"
      )
   ) {
      return;
   }

   state.exam =
      null;

   state.examId =
      null;

   state.examPath =
      "";

   state.composition =
      [];

   state.dirty =
      false;

   state.saving =
      false;

   state.status =
      "";

   state.statusError =
      false;

   state.proofAvailable =
      false;

   state.proofPdfAvailable =
      false;

   state.productionAvailable =
      false;

   state.productionPaperCount =
      0;

   state.productionPdfAvailable =
      false;

   state.productionPdfCount =
      0;

   state.productionPageCount =
      0;

   state.productionPackageAvailable = false;
   state.productionZipAvailable = false;
   state.productionCombinedPdfAvailable = false;
   state.productionPackageError = "";
   state.proofOutputExists = false;
   state.productionOutputExists = false;
   state.postExamExists = false;
   state.savedManifest = null;

   state.responsesFile =
      "";

   state.gradingAvailable =
      false;

   state.gradingExitCode =
      0;

   state.idMapFile =
      "";

   state.mailAvailable =
      false;

   state.mailExitCode =
      0;

   state.gradingOutputExists = false;

   try {
      await loadExams();
   } catch (error) {
      console.error("Could not refresh exam list:", error);
   }

   renderExams();
}


// ------------------------------------------------------------
// New exam
// ------------------------------------------------------------

export function showNewExamDialog() {
   const dialog =
      document.querySelector(
         "#newExamDialog"
      );

   const form =
      document.querySelector(
         "#newExamForm"
      );

   form.reset();

   dialog.showModal();

   form.elements.folder.focus();
}


export async function createExam(event) {
   event.preventDefault();

   const form =
      document.querySelector(
         "#newExamForm"
      );

   const dialog =
      document.querySelector(
         "#newExamDialog"
      );

   const data =
      Object.fromEntries(
         new FormData(form)
      );

   try {

      const result =
         await postJson(
            "/exams",
            data
         );

      dialog.close();

      await loadExams();

      await openExam(
         result.id
      );

   } catch (error) {

      window.alert(
         `Could not create exam.\n\n${error.message}`
      );
   }
}