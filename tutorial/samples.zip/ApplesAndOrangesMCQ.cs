using System;
using System.Collections.Generic;
using System.Text;

namespace Utilities.Courses
{
   public partial class QHelper : IQHelper
   {
      public static QuestionBase ApplesAndOrangesQ(Random random, bool isProof)
      {
         var q = new TruthQuestion(random, isProof);
         q.Id = "ApplesAndOrangesQ";
         q.Marks = 2;
         int applePrice = random.Next(4, 9) * 2;
         int orangePrice = random.Next(11, 19) * 2;
         int appleCnt1 = random.Next(2, 6) * 1;
         int orangeCnt1 = random.Next(6, 12) * 1;
         int orangeCnt2 = random.Next(12, 18) * 1;
         int appleCnt2 = random.Next(18, 24) * 1;
         var S1 = appleCnt1 * applePrice + orangeCnt1 * orangePrice;
         var S2 = appleCnt2 * applePrice + orangeCnt2 * orangePrice;
         var Dis1 = applePrice - 1;
         var Dis2 = applePrice - 2;
         var Dis3 = applePrice + 2;
         var Dis4 = applePrice + 1;
         var Dis5 = orangePrice + 1;
         var Dis6 = orangePrice + 2;
         var Dis7 = orangePrice - 2;
         var Dis8 = orangePrice - 1;
         q.Stem = $"At Prancing Pony, you can buy {appleCnt1}  apples and {orangeCnt1}  oranges for {S1}  Castars; you can also buy {appleCnt2}  apples and {orangeCnt2}  oranges for {S2}  Castars. What is the price of a single apple, expressed in Castars? ";
         q.AddCorrects(
         $"{applePrice}"
         );
         q.AddIncorrects(
         $"{Dis1}",
         $"{Dis2}",
         $"{Dis3}",
         $"{Dis4}",
         $"{Dis5}",
         $"{Dis6}",
         $"{Dis7}",
         $"{Dis8}",
         $"{orangePrice}"
         );
         return q;
      } // ApplesAndOrangesQ
   } // class
} // namespace
