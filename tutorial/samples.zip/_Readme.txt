The command to a single exam script starting with version number 42:

McqTestGen.exe -startId 42 -paperCount 1 -prologue SampleCover.html -omr OmrTemplateSouthernHem.svg ApplesAndOrangesMCQ.cs PrancingPonyLocationMCQ.cs .xx QuadraticEqMCQ.cs .\NationalCapitalsMCQ.cs

The marker .xx requests a page break after the PrancingPonyLocationMCQ question.
