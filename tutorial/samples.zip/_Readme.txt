The command to generate a single exam script starting with version number 42:

McqTestGen.exe -courseCode "LOTR101" -courseInfo "Introduction to LOTR" -startId 42 -paperCount 1 -prologue SampleCover.html -omr OmrTemplate.svg -math katex PrancingPonyLocationMCQ.cs ApplesAndOrangesMCQ.cs  NationalCapitalsMCQ.cs QuadraticEqMCQ.cs

In the following command, the marker .xx requests a page break after the ApplesAndOrangesMCQ question.

McqTestGen.exe -courseCode "LOTR101" -courseInfo "Introduction to LOTR" -startId 42 -paperCount 1 -prologue SampleCover.html -omr OmrTemplate.svg -math katex PrancingPonyLocationMCQ.cs ApplesAndOrangesMCQ.cs  .xx NationalCapitalsMCQ.cs QuadraticEqMCQ.cs

You can change the option -paperCount to, say, 100 to generate 100 scripts.

If you are using MacOS/Linux, then "McqTestGen.exe" would need to be replaced with "dotnet McqTestGen.dll" in the above commands.

