The command to generate a single exam script starting with version number 42:

McqTestGen.exe -startId 42 -paperCount 1 -prologue SampleCover.html -omr OmrTemplateSouthernHem.svg ApplesAndOrangesMCQ.cs PrancingPonyLocationMCQ.cs .xx QuadraticEqMCQ.cs .\NationalCapitalsMCQ.cs

The marker .xx requests a page break after the PrancingPonyLocationMCQ question.

You can change the option -paperCount to, say, 100 to generate 100 scripts.
