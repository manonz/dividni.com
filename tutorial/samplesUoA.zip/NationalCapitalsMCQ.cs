using System;

namespace Utilities.Courses
{
   public partial class QHelper : IQHelper
   {
      public static QuestionBase NationalCapitalsMCQ(Random random, bool isProof)
      {
         var q = new XyzQuestion(random, isProof); // Change XyzQuestion to TruthQuestion for single-response
         q.Id = "NationalCapitalsMCQ"; // The Id is used in error-reporting. Please let it be meaningful and unique.
         q.Marks = 2;
         q.Stem = "Which of the following cities are national capitals?";
         q.AddCorrects(
             "Zagreb",
             "Amsterdam",
             "Madrid",
             "Skopje",
             "Ljubljana",
             "Moscow",
             "Podgorica",
             "Beijing",
             "Brussels",
             "London",
             "Paris"
         );
         q.AddIncorrects(
             "Istanbul",
             "Auckland",
             "Sydney",
             "Mumbai (Bombay)",
             "Toronto",
             "Lublin",
             "New York",
             "Geneva",
             "Rio de Janeiro",
             "Johannesburg"
         );
         return q;
      } // NationalCapitalsMCQ
   } // class
} // namespace