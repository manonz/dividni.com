using System;
using System.Collections.Generic;
using System.Text;

namespace Utilities.Courses{
	public partial class QHelper : IQHelper
	{
		public static QuestionBase PrancingPonyLocQ(Random random, bool isProof)
		{
			var q = new TruthQuestion(random, isProof);
			q.Id = "PrancingPonyLocQ";
			q.Marks = 2;
			q.Stem = $"Where is the public house <em>Prancing Pony</em> located?\n<img style='margin: 40px;' width='150' alt='' src='https://dividni.com/images/PrancingPony.svg' />\n ";
			q.AddCorrects(
			$"Bree"
			);
			q.AddIncorrects(
			$"Isengard",
			$"Mirkwood",
			$"Shire",
			$"Rohan",
			$"Rivendell",
			$"Mordor\n"
			);
			return q;
			} // PrancingPonyLocQ
		} // class
	} // namespace
