The command to generate three exam scripts starting with version number 42:

McqTestGen.exe  -courseCode "COMPSCI 100 S1" -courseInfo "Introduction to LOTR" -startId 42 -paperCount 3 -prologue Coversheet.html -omr OmrTemplateUoA.svg PrancingPonyLocationMCQ.cs ApplesAndOrangesMCQ.cs .xx NationalCapitalsMCQ.cs

The marker .xx requests a page break after the PrancingPonyLocationMCQ question.

You can change the option -paperCount to, say, 100 to generate 100 scripts.

We can add option -css as below to change the styling of the exam papers:
McqTestGen.exe  -courseCode "COMPSCI 100 S1" -courseInfo "Introduction to LOTR" -startId 42 -paperCount 3 -prologue Coversheet.html -omr OmrTemplateUoA.svg -css exam.css -math katex PrancingPonyLocationMCQ.cs ApplesAndOrangesMCQ.cs NationalCapitalsMCQ.cs ApplesAndOrangesMCQx2.cs QuadraticEqMCQ.cs

If you are using MacOS/Linux, then McqTestGen.exe would need to be replaced with "dotnet McqTestGen.dll".



