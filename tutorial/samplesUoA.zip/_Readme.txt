The command to generate a single exam script starting with version number 42:

McqTestGen.exe -startId 42 -paperCount 1 -prologue Coversheet.html -omr OmrTemplateUoA.svg PrancingPonyLocationMCQ.cs ApplesAndOrangesMCQ.cs .xx QuadraticEqMCQ.cs .\NationalCapitalsMCQ.cs

The marker .xx requests a page break after the PrancingPonyLocationMCQ question.

You can change the option -paperCount to, say, 100 to generate 100 scripts.

We can add option -css as below to change the styling of the exam papers:
McqTestGen.exe -startId 42 -paperCount 1 -prologue Coversheet.html -omr OmrTemplateUoA.svg -css exam.css PrancingPonyLocationMCQ.cs ApplesAndOrangesMCQ.cs .xx QuadraticEqMCQ.cs .\NationalCapitalsMCQ.cs


