using System;
using System.Text;

namespace Utilities.Courses
{
   public partial class QHelper : IQHelper
   {
      public static QuestionBase QuadraticAnswerQ(Random random, bool isProof)
      {
         var q = new TruthQuestion(random, isProof);
         q.Id = "QuadraticAnswerQ"; // The Id is used in error-reporting. Please let it be meaningful and unique.
         q.Marks = 2;
         int a = random.Next(2, 5);
         int b = random.Next(6, 10);
         int x = random.Next(5, 15);
         int c = a * x * x + b * x;
         q.Stem = $"What is the positive x value that satisfies the equation {a}x<sup>2</sup> + {b}x - {c}? <br/>Note: when \\(a \\ne 0\\), there are two solutions to \\(ax^2 + bx + c = 0\\) and they are $$x = \\frac{{-b \\pm \\sqrt{{b^2-4ac}}}}{{2a}}$$.";
         q.AddCorrects(
             x.ToString()
         );
         q.AddIncorrects(
             (x + 1).ToString(),
             (x - 1).ToString(),
             (x + 2).ToString(),
             (x - 2).ToString(),
             (x + 3).ToString(),
             (x - 3).ToString()
         );
         return q;
      } // QuadraticAnswerQ
   } // class
} // namespace